package lib;

public class Utilities {

	public static int GetBit(int number, int offset) {
		return ((number & (1 << offset)) >> offset) == 1 ? 1 : 0;
	}

	public static String IntToString(int number) {
		return String.valueOf(number);
	}

}
