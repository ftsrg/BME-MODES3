/*----------------------------------------------------------------------------
 * File:  Application_Utilities_bridge.c
 *
 * Description:
 * Methods for bridging to an external entity.
 *
 * External Entity:  Utilities (Utilities)
 * 
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#include "ControlSectionsV5_sys_types.h"
#include "Application_LOG_bridge.h"
#include "Application_Utilities_bridge.h"
#include "Application_classes.h"
#include "Application_Utilities_bridge.h"
#include "ControlSectionsV5_sys_types.h"

/*
 * Bridge:  GetBit
 */
i_t
Application_Utilities_GetBit( const i_t p_number, const i_t p_offset )
{
  i_t result = 0;
  /* Insert your implementation code here... */
  return result;
}


/*
 * Bridge:  IntToString
 */
c_t *
Application_Utilities_IntToString( const i_t p_number )
{
  c_t * result = 0;
  /* Insert your implementation code here... */
  return result;
}


