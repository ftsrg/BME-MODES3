/*----------------------------------------------------------------------------
 * File:  Application.h
 *
 * UML Component (Module) Declaration (Operations and Signals)
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#ifndef APPLICATION_H
#define APPLICATION_H
#ifdef	__cplusplus
extern	"C"	{
#endif

#include "ControlSectionsV5_sys_types.h"
void Application_Port1_disableSection( const i_t );
void Application_Port1_enableSection( const i_t );
void Application_Port1_initRealized( void );
void Application_Port1_receiveOccupancy( const i_t );
void Application_Port1_triggerUnlock( void );
void Application_Port1_turnoutDivergent( const i_t );
void Application_Port1_turnoutStraight( const i_t );


#ifdef	__cplusplus
}
#endif
#endif  /* APPLICATION_H */
