/*----------------------------------------------------------------------------
 * File:  Application_StraightTurnout_class.c
 *
 * Class:       StraightTurnout  (StraightTurnout)
 * Component:   Application
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#include "ControlSectionsV5_sys_types.h"
#include "Application_LOG_bridge.h"
#include "Application_Utilities_bridge.h"
#include "Application_classes.h"


/*
 * RELATE Turnout TO StraightTurnout ACROSS R2
 */
void
Application_StraightTurnout_R2_Link( Application_Turnout * supertype, Application_StraightTurnout * subtype )
{
  /* Use TagEmptyHandleDetectionOn() to detect empty handle references.  */
  /* Optimized linkage for StraightTurnout->Turnout[R2] */
  subtype->Turnout_R2 = supertype;
  /* Optimized linkage for Turnout->StraightTurnout[R2] */
  supertype->R2_subtype = subtype;
  supertype->R2_object_id = Application_StraightTurnout_CLASS_NUMBER;
}


/*
 * UNRELATE Turnout FROM StraightTurnout ACROSS R2
 */
void
Application_StraightTurnout_R2_Unlink( Application_Turnout * supertype, Application_StraightTurnout * subtype )
{
  /* Use TagEmptyHandleDetectionOn() to detect empty handle references.  */
  subtype->Turnout_R2 = 0;
  /* Note:  Turnout->StraightTurnout[R2] not navigated */
}


/*
 * Statically allocate space for the instance population for this class.
 * Allocate space for the class instance and its attribute values.
 * Depending upon the collection scheme, allocate containoids (collection
 * nodes) for gathering instances into free and active extents.
 */
static Escher_SetElement_s Application_StraightTurnout_container[ Application_StraightTurnout_MAX_EXTENT_SIZE ];
static Application_StraightTurnout Application_StraightTurnout_instances[ Application_StraightTurnout_MAX_EXTENT_SIZE ];
Escher_Extent_t pG_Application_StraightTurnout_extent = {
  {0}, {0}, &Application_StraightTurnout_container[ 0 ],
  (Escher_iHandle_t) &Application_StraightTurnout_instances,
  sizeof( Application_StraightTurnout ), Application_StraightTurnout_STATE_1, Application_StraightTurnout_MAX_EXTENT_SIZE
  };
/*----------------------------------------------------------------------------
 * State and transition action implementations for the following class:
 *
 * Class:      StraightTurnout  (StraightTurnout)
 * Component:  Application
 *--------------------------------------------------------------------------*/

/*
 * State 1:  [Init]
 */
static void Application_StraightTurnout_act1( Application_StraightTurnout *, const Escher_xtUMLEvent_t * const );
static void
Application_StraightTurnout_act1( Application_StraightTurnout * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * divergent=0;
  /* SELECT one divergent RELATED BY self->Turnout[R2]->Section[R3.divergent] */
  divergent = 0;
  {  if ( 0 != self ) {
  Application_Turnout * Turnout_R2 = self->Turnout_R2;
  if ( 0 != Turnout_R2 ) {
  divergent = Turnout_R2->Section_R3_divergent;
}}}
  /* GENERATE Section3:sectionLocked() TO divergent */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( divergent, &Application_Sectionevent3c );
    Escher_SendEvent( e );
  }
}

/*
 * State 2:  [SwitchedDivergent]
 */
static void Application_StraightTurnout_act2( Application_StraightTurnout *, const Escher_xtUMLEvent_t * const );
static void
Application_StraightTurnout_act2( Application_StraightTurnout * self, const Escher_xtUMLEvent_t * const event )
{
  Application_DivergentTurnout * divergent;Application_Section * div=0;Application_Turnout * turnout=0;
  /* SELECT one turnout RELATED BY self->Turnout[R2] */
  turnout = ( 0 != self ) ? self->Turnout_R2 : 0;
  /* SELECT one div RELATED BY turnout->Section[R3.divergent] */
  div = ( 0 != turnout ) ? turnout->Section_R3_divergent : 0;
  /* GENERATE Section6:sectionAllowed() TO div */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( div, &Application_Sectionevent6c );
    Escher_SendEvent( e );
  }
  /* UNRELATE self FROM turnout ACROSS R2 */
  Application_StraightTurnout_R2_Unlink( turnout, self );
  /* CREATE OBJECT INSTANCE divergent OF DivergentTurnout */
  divergent = (Application_DivergentTurnout *) Escher_CreateInstance( Application_DOMAIN_ID, Application_DivergentTurnout_CLASS_NUMBER );
  /* RELATE divergent TO turnout ACROSS R2 */
  Application_DivergentTurnout_R2_Link( turnout, divergent );
  /* GENERATE Turnout8:initialized() TO divergent */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( divergent, &Application_Turnoutevent8c );
    Escher_SendEvent( e );
  }
  /* LOG::LogInfo( message:( ( Turnout  + Utilities::IntToString(turnout.id) ) +  becomes divergent. ) ) */
  Application_LOG_LogInfo( Escher_stradd( Escher_stradd( "Turnout ", Application_Utilities_IntToString( turnout->id ) ), " becomes divergent." ) );
}

/*
 * State 3:  [RequestFromStraight]
 */
static void Application_StraightTurnout_act3( Application_StraightTurnout *, const Escher_xtUMLEvent_t * const );
static void
Application_StraightTurnout_act3( Application_StraightTurnout * self, const Escher_xtUMLEvent_t * const event )
{
}

/*
 * State 4:  [RequestFromTop]
 */
static void Application_StraightTurnout_act4( Application_StraightTurnout *, const Escher_xtUMLEvent_t * const );
static void
Application_StraightTurnout_act4( Application_StraightTurnout * self, const Escher_xtUMLEvent_t * const event )
{
}

/*
 */
static void Application_StraightTurnout_xact1( Application_StraightTurnout *, const Escher_xtUMLEvent_t * const );
static void
Application_StraightTurnout_xact1( Application_StraightTurnout * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * str=0;
  /* SELECT one str RELATED BY self->Turnout[R2]->Section[R4.straight] */
  str = 0;
  {  if ( 0 != self ) {
  Application_Turnout * Turnout_R2 = self->Turnout_R2;
  if ( 0 != Turnout_R2 ) {
  str = Turnout_R2->Section_R4_straight;
}}}
  /* GENERATE Section6:sectionAllowed() TO str */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( str, &Application_Sectionevent6c );
    Escher_SendEvent( e );
  }
}

/*
 */
static void Application_StraightTurnout_xact2( Application_StraightTurnout *, const Escher_xtUMLEvent_t * const );
static void
Application_StraightTurnout_xact2( Application_StraightTurnout * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * straight=0;
  /* SELECT one straight RELATED BY self->Turnout[R2]->Section[R4.straight] */
  straight = 0;
  {  if ( 0 != self ) {
  Application_Turnout * Turnout_R2 = self->Turnout_R2;
  if ( 0 != Turnout_R2 ) {
  straight = Turnout_R2->Section_R4_straight;
}}}
  /* GENERATE Section3:sectionLocked() TO straight */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( straight, &Application_Sectionevent3c );
    Escher_SendEvent( e );
  }
}

/*
 */
static void Application_StraightTurnout_xact3( Application_StraightTurnout *, const Escher_xtUMLEvent_t * const );
static void
Application_StraightTurnout_xact3( Application_StraightTurnout * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * divergent=0;Application_Section * top=0;Application_Turnout * turnout=0;
  /* SELECT one turnout RELATED BY self->Turnout[R2] */
  turnout = ( 0 != self ) ? self->Turnout_R2 : 0;
  /* SELECT one top RELATED BY turnout->Section[R5.top] */
  top = ( 0 != turnout ) ? turnout->Section_R5_top : 0;
  /* GENERATE Section4:sectionLockedWithReply() TO top */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( top, &Application_Sectionevent4c );
    Escher_SendEvent( e );
  }
  /* SELECT one divergent RELATED BY turnout->Section[R3.divergent] */
  divergent = ( 0 != turnout ) ? turnout->Section_R3_divergent : 0;
  /* GENERATE Section3:sectionLocked() TO divergent */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( divergent, &Application_Sectionevent3c );
    Escher_SendEvent( e );
  }
}

/*
 */
static void Application_StraightTurnout_xact4( Application_StraightTurnout *, const Escher_xtUMLEvent_t * const );
static void
Application_StraightTurnout_xact4( Application_StraightTurnout * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * divergent=0;Application_Section * straight=0;Application_Turnout * turnout=0;
  /* SELECT one turnout RELATED BY self->Turnout[R2] */
  turnout = ( 0 != self ) ? self->Turnout_R2 : 0;
  /* SELECT one straight RELATED BY turnout->Section[R4.straight] */
  straight = ( 0 != turnout ) ? turnout->Section_R4_straight : 0;
  /* GENERATE Section4:sectionLockedWithReply() TO straight */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( straight, &Application_Sectionevent4c );
    Escher_SendEvent( e );
  }
  /* SELECT one divergent RELATED BY turnout->Section[R3.divergent] */
  divergent = ( 0 != turnout ) ? turnout->Section_R3_divergent : 0;
  /* GENERATE Section3:sectionLocked() TO divergent */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( divergent, &Application_Sectionevent3c );
    Escher_SendEvent( e );
  }
}

/*
 */
static void Application_StraightTurnout_xact5( Application_StraightTurnout *, const Escher_xtUMLEvent_t * const );
static void
Application_StraightTurnout_xact5( Application_StraightTurnout * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * top=0;
  /* SELECT one top RELATED BY self->Turnout[R2]->Section[R5.top] */
  top = 0;
  {  if ( 0 != self ) {
  Application_Turnout * Turnout_R2 = self->Turnout_R2;
  if ( 0 != Turnout_R2 ) {
  top = Turnout_R2->Section_R5_top;
}}}
  /* GENERATE Section6:sectionAllowed() TO top */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( top, &Application_Sectionevent6c );
    Escher_SendEvent( e );
  }
}

/*
 */
static void Application_StraightTurnout_xact6( Application_StraightTurnout *, const Escher_xtUMLEvent_t * const );
static void
Application_StraightTurnout_xact6( Application_StraightTurnout * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * top=0;
  /* SELECT one top RELATED BY self->Turnout[R2]->Section[R5.top] */
  top = 0;
  {  if ( 0 != self ) {
  Application_Turnout * Turnout_R2 = self->Turnout_R2;
  if ( 0 != Turnout_R2 ) {
  top = Turnout_R2->Section_R5_top;
}}}
  /* GENERATE Section3:sectionLocked() TO top */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( top, &Application_Sectionevent3c );
    Escher_SendEvent( e );
  }
}

const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE2c = {
  Application_DOMAIN_ID, Application_StraightTurnout_CLASS_NUMBER, APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE2NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE5c = {
  Application_DOMAIN_ID, Application_StraightTurnout_CLASS_NUMBER, APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE5NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE3c = {
  Application_DOMAIN_ID, Application_StraightTurnout_CLASS_NUMBER, APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE3NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE4c = {
  Application_DOMAIN_ID, Application_StraightTurnout_CLASS_NUMBER, APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE4NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE1c = {
  Application_DOMAIN_ID, Application_StraightTurnout_CLASS_NUMBER, APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE1NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE7c = {
  Application_DOMAIN_ID, Application_StraightTurnout_CLASS_NUMBER, APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE7NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE8c = {
  Application_DOMAIN_ID, Application_StraightTurnout_CLASS_NUMBER, APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE8NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE11c = {
  Application_DOMAIN_ID, Application_StraightTurnout_CLASS_NUMBER, APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE11NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE9c = {
  Application_DOMAIN_ID, Application_StraightTurnout_CLASS_NUMBER, APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE9NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };



/*
 * State-Event Matrix (SEM)
 * Row index is object (MC enumerated) current state.
 * Row zero is the uninitialized state (e.g., for creation event transitions).
 * Column index is (MC enumerated) state machine events.
 */
static const Escher_SEMcell_t Application_StraightTurnout_StateEventMatrix[ 4 + 1 ][ 9 ] = {
  /* row 0:  uninitialized state (for creation events) */
  { EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN },
  /* row 1:  Application_StraightTurnout_STATE_1 (Init) */
  { EVENT_IS_IGNORED, EVENT_IS_IGNORED, Application_StraightTurnout_STATE_1, Application_StraightTurnout_STATE_2, Application_StraightTurnout_STATE_1, EVENT_IS_IGNORED, (4<<8) + Application_StraightTurnout_STATE_4, EVENT_IS_IGNORED, (3<<8) + Application_StraightTurnout_STATE_3 },
  /* row 2:  Application_StraightTurnout_STATE_2 (SwitchedDivergent) */
  { EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED },
  /* row 3:  Application_StraightTurnout_STATE_3 (RequestFromStraight) */
  { EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED, Application_StraightTurnout_STATE_2, EVENT_IS_IGNORED, (2<<8) + Application_StraightTurnout_STATE_1, EVENT_IS_IGNORED, (1<<8) + Application_StraightTurnout_STATE_1, EVENT_IS_IGNORED },
  /* row 4:  Application_StraightTurnout_STATE_4 (RequestFromTop) */
  { (6<<8) + Application_StraightTurnout_STATE_1, (5<<8) + Application_StraightTurnout_STATE_1, EVENT_IS_IGNORED, Application_StraightTurnout_STATE_2, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED }
};

  /*
   * Array of pointers to the class state action procedures.
   * Index is the (MC enumerated) number of the state action to execute.
   */
  static const StateAction_t Application_StraightTurnout_acts[ 5 ] = {
    (StateAction_t) 0,
    (StateAction_t) Application_StraightTurnout_act1,  /* Init */
    (StateAction_t) Application_StraightTurnout_act2,  /* SwitchedDivergent */
    (StateAction_t) Application_StraightTurnout_act3,  /* RequestFromStraight */
    (StateAction_t) Application_StraightTurnout_act4  /* RequestFromTop */
  };

  /*
   * Array of pointers to the class transition action procedures.
   * Index is the (MC enumerated) number of the transition action to execute.
   */
  static const StateAction_t Application_StraightTurnout_xacts[ 6 ] = {
    (StateAction_t) Application_StraightTurnout_xact1,
    (StateAction_t) Application_StraightTurnout_xact2,
    (StateAction_t) Application_StraightTurnout_xact3,
    (StateAction_t) Application_StraightTurnout_xact4,
    (StateAction_t) Application_StraightTurnout_xact5,
    (StateAction_t) Application_StraightTurnout_xact6
  };

/*
 * instance state machine event dispatching
 */
void
Application_StraightTurnout_Dispatch( Escher_xtUMLEvent_t * event )
{
  Escher_iHandle_t instance = GetEventTargetInstance( event );
  Escher_EventNumber_t event_number = GetOoaEventNumber( event );
  Escher_StateNumber_t current_state;
  Escher_SEMcell_t next_state;
  
  if ( 0 != instance ) {
    current_state = instance->current_state;
    if ( current_state > 4 ) {
      /* instance validation failure (object deleted while event in flight) */
      UserEventNoInstanceCallout( event_number );
    } else {
      next_state = Application_StraightTurnout_StateEventMatrix[ current_state ][ event_number ];
      if ( next_state <= 4 ) {
        /* Execute the state action and update the current state.  */
        ( *Application_StraightTurnout_acts[ next_state ] )( instance, event );

        /* Self deletion state transition? */
        if ( next_state == Application_StraightTurnout_STATE_2 ) {          Escher_DeleteInstance( instance, Application_DOMAIN_ID, Application_StraightTurnout_CLASS_NUMBER );
        } else {
          instance->current_state = next_state;
        }
      } else if ( next_state == EVENT_IS_IGNORED ) {
          /* event ignored */
      } else {
        ( *Application_StraightTurnout_xacts[ (next_state>>8)-1 ] )( instance, event );
        next_state = next_state & 0x00ff;
        instance->current_state = next_state;
        ( *Application_StraightTurnout_acts[ next_state ] )( instance, event );
      }
    }
  }
}


