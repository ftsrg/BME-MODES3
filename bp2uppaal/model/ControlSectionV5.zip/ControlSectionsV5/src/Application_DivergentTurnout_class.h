/*----------------------------------------------------------------------------
 * File:  Application_DivergentTurnout_class.h
 *
 * Class:       DivergentTurnout  (DivergentTurnout)
 * Component:   Application
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#ifndef APPLICATION_DIVERGENTTURNOUT_CLASS_H
#define APPLICATION_DIVERGENTTURNOUT_CLASS_H

#ifdef	__cplusplus
extern	"C"	{
#endif

/*
 * Structural representation of application analysis class:
 *   DivergentTurnout  (DivergentTurnout)
 */
struct Application_DivergentTurnout {
  Escher_StateNumber_t current_state;
  /* application analysis class attributes */

  /* relationship storage */
  Application_Turnout * Turnout_R2;
};

void Application_DivergentTurnout_R2_Link( Application_Turnout *, Application_DivergentTurnout * );
void Application_DivergentTurnout_R2_Unlink( Application_Turnout *, Application_DivergentTurnout * );


#define Application_DivergentTurnout_MAX_EXTENT_SIZE 10
extern Escher_Extent_t pG_Application_DivergentTurnout_extent;

/*
 * instance event:  Turnout3*:'sectionLockFromTop'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout3. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_DivergentTurnoutevent_Turnout_PE3;
extern const Escher_xtUMLEventConstant_t Application_DivergentTurnoutevent_Turnout_PE3c;

/*
 * instance event:  Turnout5*:'passingAllowedFromTop'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout5. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_DivergentTurnoutevent_Turnout_PE5;
extern const Escher_xtUMLEventConstant_t Application_DivergentTurnoutevent_Turnout_PE5c;

/*
 * instance event:  Turnout1*:'sectionLockFromDiv'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout1. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_DivergentTurnoutevent_Turnout_PE1;
extern const Escher_xtUMLEventConstant_t Application_DivergentTurnoutevent_Turnout_PE1c;

/*
 * instance event:  Turnout4*:'passingDeniedFromTop'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout4. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_DivergentTurnoutevent_Turnout_PE4;
extern const Escher_xtUMLEventConstant_t Application_DivergentTurnoutevent_Turnout_PE4c;

/*
 * instance event:  Turnout2*:'sectionLockFromStr'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout2. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_DivergentTurnoutevent_Turnout_PE2;
extern const Escher_xtUMLEventConstant_t Application_DivergentTurnoutevent_Turnout_PE2c;

/*
 * instance event:  Turnout6*:'switchedStraight'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout6. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_DivergentTurnoutevent_Turnout_PE6;
extern const Escher_xtUMLEventConstant_t Application_DivergentTurnoutevent_Turnout_PE6c;

/*
 * instance event:  Turnout8*:'initialized'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout8. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_DivergentTurnoutevent_Turnout_PE8;
extern const Escher_xtUMLEventConstant_t Application_DivergentTurnoutevent_Turnout_PE8c;

/*
 * instance event:  Turnout10*:'passingDeniedFromDiv'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout10. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_DivergentTurnoutevent_Turnout_PE10;
extern const Escher_xtUMLEventConstant_t Application_DivergentTurnoutevent_Turnout_PE10c;

/*
 * instance event:  Turnout12*:'passingAllowedFromDiv'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout12. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_DivergentTurnoutevent_Turnout_PE12;
extern const Escher_xtUMLEventConstant_t Application_DivergentTurnoutevent_Turnout_PE12c;

/*
 * union of events targeted towards 'DivergentTurnout' state machine
 */
typedef union {
  Application_DivergentTurnoutevent_Turnout_PE3 divergentturnout31;  
  Application_DivergentTurnoutevent_Turnout_PE5 divergentturnout52;  
  Application_DivergentTurnoutevent_Turnout_PE1 divergentturnout13;  
  Application_DivergentTurnoutevent_Turnout_PE4 divergentturnout44;  
  Application_DivergentTurnoutevent_Turnout_PE2 divergentturnout25;  
  Application_DivergentTurnoutevent_Turnout_PE6 divergentturnout66;  
  Application_DivergentTurnoutevent_Turnout_PE8 divergentturnout87;  
  Application_DivergentTurnoutevent_Turnout_PE10 divergentturnout108;  
  Application_DivergentTurnoutevent_Turnout_PE12 divergentturnout129;  
} Application_DivergentTurnout_Events_u;

/*
 * enumeration of state model states for class
 */
#define Application_DivergentTurnout_STATE_1 1  /* state [1]:  (Init) */
#define Application_DivergentTurnout_STATE_2 2  /* state [2]:  (SwitchedStraight) */
#define Application_DivergentTurnout_STATE_3 3  /* state [3]:  (RequestFromTop) */
#define Application_DivergentTurnout_STATE_4 4  /* state [4]:  (RequestFromDivergent) */
/*
 * enumeration of state model event numbers
 */
#define APPLICATION_DIVERGENTTURNOUTEVENT_TURNOUT_PE12NUM 0  /* Turnout12*:'passingAllowedFromDiv' */
#define APPLICATION_DIVERGENTTURNOUTEVENT_TURNOUT_PE10NUM 1  /* Turnout10*:'passingDeniedFromDiv' */
#define APPLICATION_DIVERGENTTURNOUTEVENT_TURNOUT_PE8NUM 2  /* Turnout8*:'initialized' */
#define APPLICATION_DIVERGENTTURNOUTEVENT_TURNOUT_PE6NUM 3  /* Turnout6*:'switchedStraight' */
#define APPLICATION_DIVERGENTTURNOUTEVENT_TURNOUT_PE2NUM 4  /* Turnout2*:'sectionLockFromStr' */
#define APPLICATION_DIVERGENTTURNOUTEVENT_TURNOUT_PE4NUM 5  /* Turnout4*:'passingDeniedFromTop' */
#define APPLICATION_DIVERGENTTURNOUTEVENT_TURNOUT_PE1NUM 6  /* Turnout1*:'sectionLockFromDiv' */
#define APPLICATION_DIVERGENTTURNOUTEVENT_TURNOUT_PE5NUM 7  /* Turnout5*:'passingAllowedFromTop' */
#define APPLICATION_DIVERGENTTURNOUTEVENT_TURNOUT_PE3NUM 8  /* Turnout3*:'sectionLockFromTop' */
extern void Application_DivergentTurnout_Dispatch( Escher_xtUMLEvent_t * );

#ifdef	__cplusplus
}
#endif

#endif  /* APPLICATION_DIVERGENTTURNOUT_CLASS_H */


