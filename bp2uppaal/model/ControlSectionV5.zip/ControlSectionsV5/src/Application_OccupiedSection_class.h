/*----------------------------------------------------------------------------
 * File:  Application_OccupiedSection_class.h
 *
 * Class:       OccupiedSection  (OccupiedSection)
 * Component:   Application
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#ifndef APPLICATION_OCCUPIEDSECTION_CLASS_H
#define APPLICATION_OCCUPIEDSECTION_CLASS_H

#ifdef	__cplusplus
extern	"C"	{
#endif

/*
 * Structural representation of application analysis class:
 *   OccupiedSection  (OccupiedSection)
 */
struct Application_OccupiedSection {
  Escher_StateNumber_t current_state;
  /* application analysis class attributes */

  /* relationship storage */
  Application_Section * Section_R1;
};

void Application_OccupiedSection_R1_Link( Application_Section *, Application_OccupiedSection * );
void Application_OccupiedSection_R1_Unlink( Application_Section *, Application_OccupiedSection * );


#define Application_OccupiedSection_MAX_EXTENT_SIZE 10
extern Escher_Extent_t pG_Application_OccupiedSection_extent;

/*
 * instance event:  Section1*:'sectionFree'
 * Note:  Event is mapped from polymorphic event Section::Section1. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_OccupiedSectionevent_Section_PE1;
extern const Escher_xtUMLEventConstant_t Application_OccupiedSectionevent_Section_PE1c;

/*
 * instance event:  Section5*:'initialized'
 * Note:  Event is mapped from polymorphic event Section::Section5. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_OccupiedSectionevent_Section_PE5;
extern const Escher_xtUMLEventConstant_t Application_OccupiedSectionevent_Section_PE5c;

/*
 * instance event:  Section4*:'sectionLockedWithReply'
 * Note:  Event is mapped from polymorphic event Section::Section4. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_OccupiedSectionevent_Section_PE4;
extern const Escher_xtUMLEventConstant_t Application_OccupiedSectionevent_Section_PE4c;

/*
 * instance event:  Section3*:'sectionLocked'
 * Note:  Event is mapped from polymorphic event Section::Section3. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_OccupiedSectionevent_Section_PE3;
extern const Escher_xtUMLEventConstant_t Application_OccupiedSectionevent_Section_PE3c;

/*
 * instance event:  Section6*:'sectionAllowed'
 * Note:  Event is mapped from polymorphic event Section::Section6. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_OccupiedSectionevent_Section_PE6;
extern const Escher_xtUMLEventConstant_t Application_OccupiedSectionevent_Section_PE6c;

/*
 * instance event:  Section7*:'revokeLock'
 * Note:  Event is mapped from polymorphic event Section::Section7. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_OccupiedSectionevent_Section_PE7;
extern const Escher_xtUMLEventConstant_t Application_OccupiedSectionevent_Section_PE7c;

/*
 * union of events targeted towards 'OccupiedSection' state machine
 */
typedef union {
  Application_OccupiedSectionevent_Section_PE1 occupiedsection11;  
  Application_OccupiedSectionevent_Section_PE5 occupiedsection52;  
  Application_OccupiedSectionevent_Section_PE4 occupiedsection43;  
  Application_OccupiedSectionevent_Section_PE3 occupiedsection34;  
  Application_OccupiedSectionevent_Section_PE6 occupiedsection65;  
  Application_OccupiedSectionevent_Section_PE7 occupiedsection76;  
} Application_OccupiedSection_Events_u;

/*
 * enumeration of state model states for class
 */
#define Application_OccupiedSection_STATE_1 1  /* state [1]:  (Init) */
#define Application_OccupiedSection_STATE_2 2  /* state [2]:  (BecomesFree) */
#define Application_OccupiedSection_STATE_3 3  /* state [3]:  (BecomesUnlocked) */
#define Application_OccupiedSection_STATE_4 4  /* state [4]:  (BecomesLocked) */
/*
 * enumeration of state model event numbers
 */
#define APPLICATION_OCCUPIEDSECTIONEVENT_SECTION_PE7NUM 0  /* Section7*:'revokeLock' */
#define APPLICATION_OCCUPIEDSECTIONEVENT_SECTION_PE6NUM 1  /* Section6*:'sectionAllowed' */
#define APPLICATION_OCCUPIEDSECTIONEVENT_SECTION_PE3NUM 2  /* Section3*:'sectionLocked' */
#define APPLICATION_OCCUPIEDSECTIONEVENT_SECTION_PE4NUM 3  /* Section4*:'sectionLockedWithReply' */
#define APPLICATION_OCCUPIEDSECTIONEVENT_SECTION_PE5NUM 4  /* Section5*:'initialized' */
#define APPLICATION_OCCUPIEDSECTIONEVENT_SECTION_PE1NUM 5  /* Section1*:'sectionFree' */
extern void Application_OccupiedSection_Dispatch( Escher_xtUMLEvent_t * );

#ifdef	__cplusplus
}
#endif

#endif  /* APPLICATION_OCCUPIEDSECTION_CLASS_H */


