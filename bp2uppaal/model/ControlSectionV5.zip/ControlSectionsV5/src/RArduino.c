/*----------------------------------------------------------------------------
 * File:  RArduino.c
 *
 * UML Component Port Messages
 * Component/Module Name:  RArduino
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#include "ControlSectionsV5_sys_types.h"
#include "RArduino.h"
#include "Application.h"

/*
 * Interface:  Communication
 * Provided Port:  Port1
 * To Provider Message:  disableSection
 */
void
RArduino_Port1_disableSection( const i_t p_sectionId )
{
}

/*
 * Interface:  Communication
 * Provided Port:  Port1
 * To Provider Message:  enableSection
 */
void
RArduino_Port1_enableSection( const i_t p_sectionId )
{
}

/*
 * Interface:  Communication
 * Provided Port:  Port1
 * To Provider Message:  initRealized
 */
void
RArduino_Port1_initRealized()
{
}

/*
 * Interface:  Communication
 * Provided Port:  Port1
 * From Provider Message:  receiveOccupancy
 */
void
RArduino_Port1_receiveOccupancy( const i_t p_occupancy )
{
  Application_Port1_receiveOccupancy(  p_occupancy );
}

/*
 * Interface:  Communication
 * Provided Port:  Port1
 * From Provider Message:  triggerUnlock
 */
void
RArduino_Port1_triggerUnlock()
{
  Application_Port1_triggerUnlock();
}

/*
 * Interface:  Communication
 * Provided Port:  Port1
 * From Provider Message:  turnoutDivergent
 */
void
RArduino_Port1_turnoutDivergent( const i_t p_turnoutId )
{
  Application_Port1_turnoutDivergent(  p_turnoutId );
}

/*
 * Interface:  Communication
 * Provided Port:  Port1
 * From Provider Message:  turnoutStraight
 */
void
RArduino_Port1_turnoutStraight( const i_t p_turnoutId )
{
  Application_Port1_turnoutStraight(  p_turnoutId );
}

