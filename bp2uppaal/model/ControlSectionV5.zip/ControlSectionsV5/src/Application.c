/*----------------------------------------------------------------------------
 * File:  Application.c
 *
 * UML Component Port Messages
 * Component/Module Name:  Application
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#include "ControlSectionsV5_sys_types.h"
#include "Application.h"
#include "Application_Utilities_bridge.h"
#include "Application_LOG_bridge.h"
#include "RArduino.h"
#include "Application_classes.h"

/*
 * Interface:  Communication
 * Required Port:  Port1
 * To Provider Message:  disableSection
 */
void
Application_Port1_disableSection( const i_t p_sectionId )
{
  RArduino_Port1_disableSection(  p_sectionId );
}

/*
 * Interface:  Communication
 * Required Port:  Port1
 * To Provider Message:  enableSection
 */
void
Application_Port1_enableSection( const i_t p_sectionId )
{
  RArduino_Port1_enableSection(  p_sectionId );
}

/*
 * Interface:  Communication
 * Required Port:  Port1
 * To Provider Message:  initRealized
 */
void
Application_Port1_initRealized()
{
  RArduino_Port1_initRealized();
}

/*
 * Interface:  Communication
 * Required Port:  Port1
 * From Provider Message:  receiveOccupancy
 */
void
Application_Port1_receiveOccupancy( const i_t p_occupancy )
{
  Escher_ObjectSet_s sections_space={0}; Escher_ObjectSet_s * sections = &sections_space;
  /* SELECT many sections FROM INSTANCES OF Section */
  Escher_CopySet( sections, &pG_Application_Section_extent.active );
  /* IF ( not empty sections ) */
  if ( !Escher_SetIsEmpty( sections ) ) {
    Application_Section * section=0;
    /* FOR EACH section IN sections */
    { Escher_Iterator_s itersection;
    Application_Section * iisection;
    Escher_IteratorReset( &itersection, sections );
    while ( (iisection = (Application_Section *)Escher_IteratorNext( &itersection )) != 0 ) {
      section = iisection; {
      /* IF ( ( Utilities::GetBit(PARAM.occupancy, section.id) == 1 ) ) */
      if ( ( Application_Utilities_GetBit( p_occupancy, section->id ) == 1 ) ) {
        /* GENERATE Section2:sectionOccupied() TO section */
        { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( section, &Application_Sectionevent2c );
          Escher_SendEvent( e );
        }
      }
      else {
        /* GENERATE Section1:sectionFree() TO section */
        { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( section, &Application_Sectionevent1c );
          Escher_SendEvent( e );
        }
      }
    }}}
  }
  Escher_ClearSet( sections );
}

/*
 * Interface:  Communication
 * Required Port:  Port1
 * From Provider Message:  triggerUnlock
 */
void
Application_Port1_triggerUnlock()
{
  Escher_ObjectSet_s occupiedSections_space={0}; Escher_ObjectSet_s * occupiedSections = &occupiedSections_space;
  /* SELECT many occupiedSections FROM INSTANCES OF OccupiedSection */
  Escher_CopySet( occupiedSections, &pG_Application_OccupiedSection_extent.active );
  /* IF ( not empty occupiedSections ) */
  if ( !Escher_SetIsEmpty( occupiedSections ) ) {
    Application_OccupiedSection * occupiedSection=0;
    /* FOR EACH occupiedSection IN occupiedSections */
    { Escher_Iterator_s iteroccupiedSection;
    Application_OccupiedSection * iioccupiedSection;
    Escher_IteratorReset( &iteroccupiedSection, occupiedSections );
    while ( (iioccupiedSection = (Application_OccupiedSection *)Escher_IteratorNext( &iteroccupiedSection )) != 0 ) {
      occupiedSection = iioccupiedSection; {
      /* GENERATE Section7:revokeLock() TO occupiedSection */
      { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( occupiedSection, &Application_Sectionevent7c );
        Escher_SendEvent( e );
      }
    }}}
  }
  Escher_ClearSet( occupiedSections );
}

/*
 * Interface:  Communication
 * Required Port:  Port1
 * From Provider Message:  turnoutDivergent
 */
void
Application_Port1_turnoutDivergent( const i_t p_turnoutId )
{
  Application_Turnout * turnout=0;
  /* SELECT any turnout FROM INSTANCES OF Turnout WHERE ( SELECTED.id == PARAM.turnoutId ) */
  turnout = 0;
  { Application_Turnout * selected;
    Escher_Iterator_s iterturnoutApplication_Turnout;
    Escher_IteratorReset( &iterturnoutApplication_Turnout, &pG_Application_Turnout_extent.active );
    while ( (selected = (Application_Turnout *) Escher_IteratorNext( &iterturnoutApplication_Turnout )) != 0 ) {
      if ( ( selected->id == p_turnoutId ) ) {
        turnout = selected;
        break;
      }
    }
  }
  /* IF ( not empty turnout ) */
  if ( !( 0 == turnout ) ) {
    /* GENERATE Turnout7:switchedDivergent() TO turnout */
    { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( turnout, &Application_Turnoutevent7c );
      Escher_SendEvent( e );
    }
  }
}

/*
 * Interface:  Communication
 * Required Port:  Port1
 * From Provider Message:  turnoutStraight
 */
void
Application_Port1_turnoutStraight( const i_t p_turnoutId )
{
  Application_Turnout * turnout=0;
  /* SELECT any turnout FROM INSTANCES OF Turnout WHERE ( SELECTED.id == PARAM.turnoutId ) */
  turnout = 0;
  { Application_Turnout * selected;
    Escher_Iterator_s iterturnoutApplication_Turnout;
    Escher_IteratorReset( &iterturnoutApplication_Turnout, &pG_Application_Turnout_extent.active );
    while ( (selected = (Application_Turnout *) Escher_IteratorNext( &iterturnoutApplication_Turnout )) != 0 ) {
      if ( ( selected->id == p_turnoutId ) ) {
        turnout = selected;
        break;
      }
    }
  }
  /* IF ( not empty turnout ) */
  if ( !( 0 == turnout ) ) {
    /* GENERATE Turnout6:switchedStraight() TO turnout */
    { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( turnout, &Application_Turnoutevent6c );
      Escher_SendEvent( e );
    }
  }
}

/*
 * UML Domain Functions (Synchronous Services)
 */

/*
 * Domain Function:  initializeModel
 */
void
Application_initializeModel()
{
  Application_StraightTurnout * strTurnout;Application_Turnout * turnout;Application_FreeSection * fTop;Application_Section * top;Application_FreeSection * fStraight;Application_Section * straight;Application_FreeSection * fDivergent;Application_Section * divergent;
  /* CREATE OBJECT INSTANCE divergent OF Section */
  divergent = (Application_Section *) Escher_CreateInstance( Application_DOMAIN_ID, Application_Section_CLASS_NUMBER );
  /* ASSIGN divergent.id = 23 */
  divergent->id = 23;
  /* CREATE OBJECT INSTANCE fDivergent OF FreeSection */
  fDivergent = (Application_FreeSection *) Escher_CreateInstance( Application_DOMAIN_ID, Application_FreeSection_CLASS_NUMBER );
  /* RELATE fDivergent TO divergent ACROSS R1 */
  Application_FreeSection_R1_Link( divergent, fDivergent );
  /* GENERATE Section5:initialized() TO fDivergent */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( fDivergent, &Application_Sectionevent5c );
    Escher_SendEvent( e );
  }
  /* CREATE OBJECT INSTANCE straight OF Section */
  straight = (Application_Section *) Escher_CreateInstance( Application_DOMAIN_ID, Application_Section_CLASS_NUMBER );
  /* ASSIGN straight.id = 11 */
  straight->id = 11;
  /* CREATE OBJECT INSTANCE fStraight OF FreeSection */
  fStraight = (Application_FreeSection *) Escher_CreateInstance( Application_DOMAIN_ID, Application_FreeSection_CLASS_NUMBER );
  /* RELATE fStraight TO straight ACROSS R1 */
  Application_FreeSection_R1_Link( straight, fStraight );
  /* GENERATE Section5:initialized() TO fStraight */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( fStraight, &Application_Sectionevent5c );
    Escher_SendEvent( e );
  }
  /* CREATE OBJECT INSTANCE top OF Section */
  top = (Application_Section *) Escher_CreateInstance( Application_DOMAIN_ID, Application_Section_CLASS_NUMBER );
  /* ASSIGN top.id = 8 */
  top->id = 8;
  /* CREATE OBJECT INSTANCE fTop OF FreeSection */
  fTop = (Application_FreeSection *) Escher_CreateInstance( Application_DOMAIN_ID, Application_FreeSection_CLASS_NUMBER );
  /* RELATE fTop TO top ACROSS R1 */
  Application_FreeSection_R1_Link( top, fTop );
  /* GENERATE Section5:initialized() TO fTop */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( fTop, &Application_Sectionevent5c );
    Escher_SendEvent( e );
  }
  /* CREATE OBJECT INSTANCE turnout OF Turnout */
  turnout = (Application_Turnout *) Escher_CreateInstance( Application_DOMAIN_ID, Application_Turnout_CLASS_NUMBER );
  /* ASSIGN turnout.id = 131 */
  turnout->id = 131;
  /* RELATE turnout TO divergent ACROSS R3 */
  Application_Turnout_R3_Link_connects_from_divergent( divergent, turnout );
  /* RELATE turnout TO straight ACROSS R4 */
  Application_Turnout_R4_Link_connects_from_straight( straight, turnout );
  /* RELATE turnout TO top ACROSS R5 */
  Application_Turnout_R5_Link_connects_from_top( top, turnout );
  /* CREATE OBJECT INSTANCE strTurnout OF StraightTurnout */
  strTurnout = (Application_StraightTurnout *) Escher_CreateInstance( Application_DOMAIN_ID, Application_StraightTurnout_CLASS_NUMBER );
  /* RELATE strTurnout TO turnout ACROSS R2 */
  Application_StraightTurnout_R2_Link( turnout, strTurnout );
  /* GENERATE Turnout8:initialized() TO strTurnout */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( strTurnout, &Application_Turnoutevent8c );
    Escher_SendEvent( e );
  }
  /* Port1::initRealized() */
  Application_Port1_initRealized();

}

/* xtUML class info (collections, sizes, etc.) */
Escher_Extent_t * const Application_class_info[ Application_MAX_CLASS_NUMBERS ] = {
  &pG_Application_Section_extent,
  &pG_Application_FreeSection_extent,
  &pG_Application_OccupiedSection_extent,
  &pG_Application_Turnout_extent,
  &pG_Application_StraightTurnout_extent,
  &pG_Application_DivergentTurnout_extent
};

/*
 * Array of pointers to the class event dispatcher method.
 * Index is the (model compiler enumerated) number of the state model.
 */
const EventTaker_t Application_EventDispatcher[ Application_STATE_MODELS ] = {
  Application_class_dispatchers
};

void Application_execute_initialization()
{
  /*
   * Initialization Function:  initializeModel
   * Component:  Application
   */
  Application_initializeModel();

}
