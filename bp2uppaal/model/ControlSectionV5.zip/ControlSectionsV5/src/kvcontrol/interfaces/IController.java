package kvcontrol.interfaces;

import java.io.IOException;
import java.net.InetAddress;

/**
 * A general interface for controllers
 * <p>
 * 
 * @author zsoltmazlo
 */
public interface IController {

	/**
	 * Send an UDP packet to the destination.
	 * 
	 * @param destination
	 *            Destination device's IP address
	 * @param message
	 *            byte array of the message
	 *            <p>
	 * @return true, if the sending was successful otherwise false
	 * @throws java.io.IOException
	 *             if socket failed
	 */
	public boolean sendUDPPacket(InetAddress destination, byte[] message)
			throws IOException;

	/**
	 * all the requester threads are designed not to ruin the network, so every
	 * thread got an 'heartbeat' which could handled by outside the class.
	 * 
	 * Because of that, if you want one measuring only, then you should call
	 * this method once, but if you want trigger the system periodically, then
	 * you are able to create a thread which call this method a sleep time on
	 * your own.
	 */
	public void sendHeartBeat();

	/**
	 * starts the receiver and requester thread inside the object. The receiver
	 * thread is running continuosly while the requester thread need's an
	 * 'heartbeat'
	 * 
	 * @see sendHeartBeat method for more details
	 */
	public void startThreads();

	/**
	 * A Runnable class stub which handling the heartbeat pattern.
	 */
	public abstract class RunnableStub implements Runnable {

		protected volatile boolean isRunning = true;
		protected final Object heartBeat;

		protected RunnableStub(Object syncObject) {
			this.heartBeat = syncObject;
		}

		public void stop() {
			isRunning = false;
		}

		@Override
		protected void finalize() throws Throwable {
			this.stop();
			synchronized (heartBeat) {
				heartBeat.notify();
			}
		}
	}

	/**
	 * Stops the entire system. Only for BridgePoint purposes!
	 * 
	 * @throws Throwable
	 */
	public void stopSystem() throws Throwable;
}
