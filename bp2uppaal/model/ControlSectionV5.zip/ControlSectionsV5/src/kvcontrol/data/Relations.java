package kvcontrol.data;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import kvcontrol.entities.Section;
import kvcontrol.entities.Turnout;

/**
 * A data class for storing sections and turnouts of the layout
 * <p>
 * 
 * @author zsoltmazlo, benedekh
 */
public class Relations {

	/**
	 * Stores all sections' ID and the responsible controller they belong to.
	 * array of [section's ID, controller's ID]
	 */
	private static final int[][] sections = { { 0x03, 0x83 }, { 0x08, 0x83 },
			{ 0x0B, 0x83 }, { 0x17, 0x83 } };

	/**
	 * Stores all turnouts' ID and the responsible controller they belong to.
	 * array of [turnout's ID, controller's ID]
	 */
	private static final int[][] turnouts = { { 0x83, 0x83 } };

	/**
	 * All turnouts' ID and the responsible controller they belong are stored
	 * here.
	 */
	private static ConcurrentMap<String, Turnout> turnoutMap = null;

	/**
	 * All sections' ID and the responsible controller they belong are stored
	 * here.
	 */
	private static ConcurrentMap<String, Section> sectionMap = null;

	/**
	 * Get Map of turnout and the responsible controller they belong to.
	 * 
	 * @return a Map of turnouts
	 */
	public static ConcurrentMap<String, Turnout> getTurnouts() {
		if (turnoutMap == null) {
			turnoutMap = new ConcurrentHashMap<String, Turnout>();
			for (int[] idPair : turnouts) {
				turnoutMap.put(getKey(idPair[0]), new Turnout(idPair[0],
						idPair[1]));
			}
		}
		return turnoutMap;
	}

	/**
	 * Get Map of sections and the responsible controller they belong to.
	 * 
	 * @return a Map of sections
	 */
	public static ConcurrentMap<String, Section> getSections() {
		if (sectionMap == null) {
			sectionMap = new ConcurrentHashMap<String, Section>();
			for (int[] idPair : sections) {
				sectionMap.put(getKey(idPair[0]), new Section(idPair[0],
						idPair[1]));
			}
		}
		return sectionMap;
	}

	/**
	 * create a usable key for Map classes from byte ID.
	 * <p>
	 * 
	 * @param ID
	 *            hashable ID
	 *            <p>
	 * @return String hash
	 */
	public static String getKey(byte ID) {
		return String.format("0x%02X", ID);
	}

	/**
	 * create a usable key for Map classes from byte ID.
	 * <p>
	 * 
	 * @param ID
	 *            hashable ID
	 *            <p>
	 * @return String hash
	 */
	public static String getKey(int ID) {
		return String.format("0x%02X", ID);
	}
}
