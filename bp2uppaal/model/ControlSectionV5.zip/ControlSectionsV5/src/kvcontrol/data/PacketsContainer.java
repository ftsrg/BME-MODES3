package kvcontrol.data;

import java.net.DatagramPacket;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * A Holder class for UDP packets.
 * <p>
 * 
 * @author zsoltmazlo
 */
public class PacketsContainer {

	/**
	 * All packets, which should handled by a TurnoutController are added to
	 * this queue.
	 * <p>
	 * only TurnoutController instances should send packets which will generate
	 * a response for TurnoutController instances!
	 */
	public static final ConcurrentLinkedQueue<DatagramPacket> turnoutPackets = new ConcurrentLinkedQueue<DatagramPacket>();

	/**
	 * All packets, which should handled by a SectionController are added to
	 * this queue.
	 * <p>
	 * only SectionController instances should send packets which will generate
	 * a response for SectionController instances!
	 */
	public static final ConcurrentLinkedQueue<DatagramPacket> sectionPackets = new ConcurrentLinkedQueue<DatagramPacket>();

	/**
	 * All packets, which should handled by a OccupancyController are added to
	 * this queue.
	 * <p>
	 * only OccupancyController instances should send packets which will
	 * generate a response for OccupancyController instances!
	 */
	public static final ConcurrentLinkedQueue<DatagramPacket> occupancyPackets = new ConcurrentLinkedQueue<DatagramPacket>();

}
