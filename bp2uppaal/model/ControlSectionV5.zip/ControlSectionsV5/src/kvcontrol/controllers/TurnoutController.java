package kvcontrol.controllers;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;

import kvcontrol.data.Commands;
import kvcontrol.data.PacketsContainer;
import kvcontrol.data.Relations;
import kvcontrol.entities.Turnout;
import kvcontrol.exceptions.NotFoundException;
import kvcontrol.exceptions.ProgramFlowException;
import kvcontrol.interfaces.IController;
import kvcontrol.interfaces.ITurnoutController;

import com.mentor.nucleus.bp.core.CorePlugin;
import components.RArduino;

/**
 * A controller for handling all turnouts status defined in turnouts.ini
 * 
 * @author zsoltmazlo
 */
public class TurnoutController extends AbstractController implements
		ITurnoutController {

	/**
	 * a reference of turnouts' Map which contains all turnouts' status
	 */
	private final ConcurrentMap<String, Turnout> turnouts;

	private final Requester requesterObject;
	private final Recevier receiverObject;

	/**
	 * A controller for handling all turnouts status defined in turnouts.ini
	 * 
	 * @param port
	 *            port number for UDP communication
	 * @param hostAddress
	 *            IP address of the host UDP communication
	 */
	public TurnoutController(int port, String hostAddress) {
		super(port, hostAddress);
		this.turnouts = Relations.getTurnouts();
		requesterObject = new Requester(this.heartBeat);
		requester = new Thread(requesterObject);
		receiverObject = new Recevier(this.heartBeat);
		receiver = new Thread(receiverObject);
	}

	@Override
	public boolean isTurnoutDivergent(int turnoutID) throws NotFoundException {
		Turnout t = this.turnouts.get(Relations.getKey(turnoutID));
		if (t == null) {
			throw new NotFoundException(String.format(
					"Turnout with %d ID is not found!", turnoutID));
		}
		return t.isDivergent();
	}

	@Override
	public boolean isTurnoutStraight(int turnoutID) throws NotFoundException {
		Turnout t = this.turnouts.get(Relations.getKey(turnoutID));
		if (t == null) {
			throw new NotFoundException(String.format(
					"Turnout with %d ID is not found!", turnoutID));
		}
		return t.isStraight();
	}

	private class Recevier extends IController.RunnableStub {

		private final ConcurrentLinkedQueue<DatagramPacket> packets = PacketsContainer.turnoutPackets;

		public Recevier(Object syncObject) {
			super(syncObject);
		}

		@Override
		public void run() {

			while (this.isRunning) {
				while (!packets.isEmpty()) {
					DatagramPacket packet = packets.poll();
					byte[] received = packet.getData();
					switch (received[0]) {
					case Commands.COMMAND_SEND_TURNOUT_STATUS:
						String key = Relations.getKey(received[1]);
						Turnout t = turnouts.get(key);
						if (t != null) {
							t.setMeasuredValues(received[2], received[3]);
							turnouts.put(key, t);
						}
						break;
					}
				}

				synchronized (packets) {
					try {
						packets.wait();
						if (RArduino.DEBUG_ENABLED) {
							CorePlugin.out
									.println("TURNOUT STATUS wait block.");
						}
					} catch (InterruptedException ex) {
						CorePlugin.out.println(ex.getMessage());
					}
				}

			}
		}

		@Override
		protected void finalize() throws Throwable {
			try {
				synchronized (packets) {
					packets.notify();
				}
			} catch (Throwable t) {
				throw t;
			} finally {
				super.finalize();
			}
		}
	}

	private class Requester extends IController.RunnableStub {

		public Requester(Object syncObject) {
			super(syncObject);
		}

		@Override
		public void run() {

			String controllerIP;
			String controllerIPBase = "192.168.1.";

			while (this.isRunning) {

				// System.out.println("new request");
				// sending an UDP message for all controllers requiring
				// turnouts' status
				for (Turnout turnout : turnouts.values()) {

					// System.out.println(turnout.getResponsibleControllerID());
					try {
						byte[] message = { Commands.COMMAND_GET_TURNOUT_STATUS,
								(byte) turnout.getID() };
						controllerIP = controllerIPBase
								+ String.format("%d",
										turnout.getResponsibleControllerID());
						// controllerIP = controllerIPBase + String.format("%d",
						// 255); // old solution, broadcast address
						InetAddress controllerAddress = InetAddress
								.getByName(controllerIP);
						boolean isSended = sendUDPPacket(controllerAddress,
								message);
						if (!isSended) {
							throw new ProgramFlowException(
									"Packet is not sended!");
						}
						Thread.sleep(10);
					} catch (UnknownHostException ex) {
						CorePlugin.out.println(ex.getMessage());
					} catch (IOException ex) {
						CorePlugin.out.println(ex.getMessage());
					} catch (ProgramFlowException ex) {
						CorePlugin.out.println(ex.getMessage());
					} catch (Exception ex) {
						CorePlugin.out.println(ex.getMessage());
					}

				}

				synchronized (this.heartBeat) {
					try {
						this.heartBeat.wait();
					} catch (InterruptedException ex) {
						CorePlugin.out.println(ex.getMessage());
					}
				}
			}
		}

		@Override
		protected void finalize() throws Throwable {
			super.finalize();
		}

	}

	@Override
	public void stopSystem() throws Throwable {
		super.stopSystem();
		requesterObject.finalize();
		receiverObject.finalize();
	}

}
