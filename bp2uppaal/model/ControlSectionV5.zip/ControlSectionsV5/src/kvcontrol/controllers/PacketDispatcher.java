package kvcontrol.controllers;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

import kvcontrol.data.Commands;
import kvcontrol.data.PacketsContainer;

import com.mentor.nucleus.bp.core.CorePlugin;
import components.RArduino;

/**
 * This class is responsible for handling all UDP packets which send to the host
 * and dispatch them to the controller threads.
 * <p>
 * 
 * @author zsoltmazlo, benedekh
 */
public class PacketDispatcher implements Runnable {

	private volatile boolean isRunning = true;
	private final DatagramSocket socket;

	public PacketDispatcher(DatagramSocket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {

		byte[] buffer = new byte[AbstractController.UDP_PACKET_SIZE];
		DatagramPacket packet;

		while (isRunning) {

			if (this.socket != null) {
				packet = new DatagramPacket(buffer, buffer.length);
				try {
					this.socket.receive(packet);
					byte received[] = packet.getData();
					switch (received[0]) {
					case Commands.COMMAND_SEND_TURNOUT_STATUS:
						PacketsContainer.turnoutPackets.add(packet);
						synchronized (PacketsContainer.turnoutPackets) {
							PacketsContainer.turnoutPackets.notify();
						}
						if (RArduino.DEBUG_ENABLED) {
							CorePlugin.out.println("packet received "
									+ "TURNOUT status");
						}
						break;
					case Commands.COMMAND_SEND_SECTION_STATUS:
						PacketsContainer.sectionPackets.add(packet);
						synchronized (PacketsContainer.sectionPackets) {
							PacketsContainer.sectionPackets.notify();
						}
						if (RArduino.DEBUG_ENABLED) {
							CorePlugin.out.println("packet received "
									+ "SECTION status");
						}
						break;
					case Commands.COMMAND_SEND_OCCUPANCY:
						PacketsContainer.occupancyPackets.add(packet);
						synchronized (PacketsContainer.occupancyPackets) {
							PacketsContainer.occupancyPackets.notify();
						}
						if (RArduino.DEBUG_ENABLED) {
							CorePlugin.out.println("packet received "
									+ "OCCUPANCY status");
						}
						break;
					}

				} catch (IOException ex) {
					CorePlugin.out.println(ex.getMessage());
				}

			}

		}
	}

	/**
	 * Make the thread stop.
	 */
	public void stop() {
		isRunning = false;
	}

	@Override
	protected void finalize() throws Throwable {
		stop();
		if (!this.socket.isClosed()) {
			this.socket.close();
		}
	}

}
