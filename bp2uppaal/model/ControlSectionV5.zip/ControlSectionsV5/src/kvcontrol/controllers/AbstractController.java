package kvcontrol.controllers;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import kvcontrol.interfaces.IController;

import com.mentor.nucleus.bp.core.CorePlugin;

/**
 * general controller class for common functionality
 * <p>
 * 
 * @author zsoltmazlo
 */
public abstract class AbstractController implements IController {

	protected static DatagramSocket socket;
	protected int port;

	protected static InetAddress broadcastAddress;
	protected InetAddress myAddress;

	protected static final int UDP_PACKET_SIZE = 64;

	protected final Object heartBeat = new Object();

	protected Thread requester;
	protected Thread receiver;

	protected static Thread commonReceiver;
	private static PacketDispatcher commonDispatcher;

	/**
	 * 
	 * @param port
	 *            port number for UDP communication
	 * @param hostAddress
	 *            host's IP address as a string (eg.: 192.168.1.163)
	 */
	public AbstractController(int port, String hostAddress) {
		try {
			this.port = port;
			this.myAddress = InetAddress.getByName(hostAddress);
			broadcastAddress = InetAddress.getByName("192.168.1.255");
			if (AbstractController.socket == null) {
				System.out.println("socket is already exist");
				AbstractController.socket = new DatagramSocket(this.port,
						this.myAddress);
				commonDispatcher = new PacketDispatcher(socket);
				AbstractController.commonReceiver = new Thread(commonDispatcher);
			}
		} catch (UnknownHostException ex) {
			CorePlugin.out.println(ex.getMessage());
		} catch (SocketException ex) {
			CorePlugin.out.println(ex.getMessage());
		}
	}

	@Override
	public void startThreads() {
		if (this.receiver != null) {
			this.receiver.start();
		}
		if (this.requester != null) {
			this.requester.start();
		}
		if (!AbstractController.commonReceiver.isAlive()) {
			AbstractController.commonReceiver.start();
		}
	}

	@Override
	public boolean sendUDPPacket(InetAddress destination, byte[] message)
			throws IOException {

		DatagramPacket packet = new DatagramPacket(message, message.length,
				destination, this.port);
		if (socket != null) {
			socket.send(packet);
			return true;
		}
		return false;
	}

	@Override
	public void sendHeartBeat() {
		synchronized (this.heartBeat) {
			this.heartBeat.notifyAll();
		}
	}

	@Override
	public void stopSystem() throws Throwable {
		commonDispatcher.finalize();
	}
}
