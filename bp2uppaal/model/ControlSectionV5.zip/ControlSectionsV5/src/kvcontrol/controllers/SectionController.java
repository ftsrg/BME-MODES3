package kvcontrol.controllers;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import kvcontrol.data.Commands;
import kvcontrol.data.PacketsContainer;
import kvcontrol.data.Relations;
import kvcontrol.entities.Section;
import kvcontrol.exceptions.NotFoundException;
import kvcontrol.exceptions.ProgramFlowException;
import kvcontrol.interfaces.IController;
import kvcontrol.interfaces.ISectionController;

import com.mentor.nucleus.bp.core.CorePlugin;
import components.RArduino;

/**
 * A controller for handling all sections status defined in sections.ini
 * <p>
 * 
 * @author zsoltmazlo, benedekh
 */
public class SectionController extends AbstractController implements
		ISectionController {

	private final ConcurrentMap<String, Section> sections;

	private final Requester requesterObject;
	private final Recevier receiverObject;

	public SectionController(int port, String myAddress) {
		super(port, myAddress);
		sections = Relations.getSections();
		requesterObject = new Requester(this.heartBeat);
		requester = new Thread(requesterObject);
		receiverObject = new Recevier(this.heartBeat);
		receiver = new Thread(receiverObject);
	}

	@Override
	public void setSectionEnabled(int sectionID) throws NotFoundException {
		Section section = sections.get(Relations.getKey(sectionID));
		if (section != null) {
			this.sendSectionCommand(section, Commands.COMMAND_LINE_ENABLE);
		} else {
			throw new NotFoundException(String.format(
					"Section with %d ID is not found!", sectionID));
		}
	}

	@Override
	public void setSectionDisabled(int sectionID) throws NotFoundException {
		Section section = sections.get(Relations.getKey(sectionID));
		if (section != null) {
			this.sendSectionCommand(section, Commands.COMMAND_LINE_DISABLE);
		} else {
			throw new NotFoundException(String.format(
					"Section with %d ID is not found!", sectionID));
		}
	}

	@Override
	public boolean isSectionEnabled(int sectionID) throws NotFoundException {
		Section section = sections.get(Relations.getKey(sectionID));
		if (section != null) {
			return section.isEnabled();
		} else {
			throw new NotFoundException(String.format(
					"Section with %d ID is not found!", sectionID));
		}
	}

	/**
	 * Sends an UDP message to the selected section's controller. The content of
	 * the message depends on the command.
	 * 
	 * @param section
	 *            the selected section, whose controller should be contacted
	 * @param command
	 *            the command to be sent to the section's controller
	 */
	private void sendSectionCommand(Section section, byte command) {
		try {
			int controllerID = section.getResponsibleControllerID();
			InetAddress controllerAddress = InetAddress.getByName("192.168.1."
					+ controllerID);
			// InetAddress controllerAddress = broadcastAddress; // old
			// solution, boradcast address
			byte[] message = new byte[] { command, (byte) section.getID() };
			boolean isSended = sendUDPPacket(controllerAddress, message);
			if (!isSended) {
				throw new ProgramFlowException("Packet is not sended!");
			}
		} catch (Exception ex) {
			CorePlugin.out.println(ex.getMessage());
		}
	}

	/**
	 * Receives and stores the sections' status frequently, whether they are
	 * enabled.
	 */
	private class Recevier extends IController.RunnableStub {

		private final ConcurrentLinkedQueue<DatagramPacket> packets = PacketsContainer.sectionPackets;

		public Recevier(Object syncObject) {
			super(syncObject);
		}

		@Override
		public void run() {
			while (this.isRunning) {

				while (!packets.isEmpty()) {
					DatagramPacket packet = packets.poll();
					byte[] received = packet.getData();
					switch (received[0]) {
					case Commands.COMMAND_SEND_SECTION_STATUS:
						String key = Relations.getKey(received[1]);
						Section section = sections.get(key);
						if (section != null) {
							if (received[2] == 0) {
								section.setIsEnabled(true);
							} else {
								section.setIsEnabled(false);
							}
							sections.put(key, section);
						}
						break;
					}
				}

				synchronized (packets) {
					try {
						packets.wait();
						if (RArduino.DEBUG_ENABLED) {
							CorePlugin.out
									.println("SECTION CONTROLLER wait block.");
						}
					} catch (InterruptedException ex) {
						Logger.getLogger(TurnoutController.class.getName())
								.log(Level.SEVERE, null, ex);
					}
				}
			}
		}

		@Override
		protected void finalize() throws Throwable {
			try {
				synchronized (packets) {
					packets.notify();
				}
			} catch (Throwable t) {
				throw t;
			} finally {
				super.finalize();
			}
		}

	}

	/**
	 * Polls the sections' frequently, whether they are enabled.
	 */
	private class Requester extends IController.RunnableStub {

		public Requester(Object syncObject) {
			super(syncObject);
		}

		@Override
		public void run() {
			while (this.isRunning) {
				try {
					for (String sectionID : sections.keySet()) {
						sendSectionCommand(sections.get(sectionID),
								Commands.COMMAND_GET_SECTION_STATUS);
						Thread.sleep(10);
					}
				} catch (InterruptedException ex) {
					Logger.getLogger(OccupancyController.class.getName()).log(
							Level.SEVERE, null, ex);
				}

				synchronized (this.heartBeat) {
					try {
						this.heartBeat.wait();
					} catch (InterruptedException ex) {
						Logger.getLogger(OccupancyController.class.getName())
								.log(Level.SEVERE, null, ex);
					}
				}
			}
		}

		@Override
		protected void finalize() throws Throwable {
			super.finalize();
		}

	}

	@Override
	public void stopSystem() throws Throwable {
		super.stopSystem();
		requesterObject.finalize();
		receiverObject.finalize();
	}

}
