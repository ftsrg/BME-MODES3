package kvcontrol.controllers;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import kvcontrol.data.Commands;
import kvcontrol.data.PacketsContainer;
import kvcontrol.data.Relations;
import kvcontrol.interfaces.IController;
import kvcontrol.interfaces.IOccupancyController;
import kvcontrol.entities.Section;
import kvcontrol.exceptions.NotFoundException;
import kvcontrol.exceptions.ProgramFlowException;

/**
 * A controller for handling all sections occupancy.
 * <p>
 * @author zsoltmazlo, benedekh
 */
public class OccupancyController extends AbstractController implements IOccupancyController {

    private final ConcurrentMap<String, Section> sections;
    private volatile int occupancyVector;

    public OccupancyController(int port, String myAddress) {
        super(port, myAddress);
        sections = Relations.getSections();
        requester = new Thread(new Requester(this.heartBeat));
        receiver = new Thread(new Recevier(this.heartBeat));
        occupancyVector = 0;
    }

    @Override
    public boolean isSectionOccupied(int sectionID) throws NotFoundException {
        Section section = sections.get(Relations.getKey(sectionID));
        if (section != null) {
            return section.isOccupied();
        } else {
            throw new NotFoundException(String.format("Section with %d ID is not found!", sectionID));
        }
    }

    @Override
    public int getOccupancyVector() {
        return this.occupancyVector;
    }

    /**
     * Receives the sections' occupancy, and sets the sections occupancy
     * according to it.
     */
    private class Recevier extends IController.RunnableStub {

        private final ConcurrentLinkedQueue<DatagramPacket> packets = PacketsContainer.occupancyPackets;

        public Recevier(Object syncObject) {
            super(syncObject);
        }

        private int getOccupancyVector(byte[] received) {
            int[] receivedInt = new int[4];

            for (int i = 1; i < 5; i++) {
                receivedInt[i - 1] = ((int) received[i] & 0xFF);
            }

            int occupancy = (receivedInt[3] << 24) | (receivedInt[2] << 16)
                    | (receivedInt[1] << 8) | (receivedInt[0]);

            return occupancy;
        }

        private int getBit(long number, int offset) {
            return ((number & (1 << offset)) >> offset) == 1 ? 1 : 0;
        }

        @Override
        public void run() {
            while (this.isRunning) {
                while (!packets.isEmpty()) {
                    DatagramPacket packet = packets.poll();
                    byte[] received = packet.getData();
                    switch (received[0]) {
                        case Commands.COMMAND_SEND_OCCUPANCY:
                            occupancyVector = getOccupancyVector(received);
                            for (Map.Entry<String, Section> sectionEntry : sections.entrySet()) {
                                Section section = sectionEntry.getValue();
                                if (getBit(occupancyVector, section.getID()) == 1) {
                                    section.setIsOccupied(true);
                                } else {
                                    section.setIsOccupied(false);
                                }
                                sections.put(sectionEntry.getKey(), section);
                            }
                            break;
                    }
                }

                synchronized (packets) {
                    try {
                        packets.wait();
                    } catch (InterruptedException ex) {
                        Logger.getLogger(TurnoutController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }

        @Override
        protected void finalize() throws Throwable {
            try {
                synchronized (packets) {
                    packets.notify();
                }
            } catch (Throwable t) {
                throw t;
            } finally {
                super.finalize();
            }
        }
    }

    /**
     * Polls the sections' frequently, whether they are occupied.
     */
    private class Requester extends IController.RunnableStub {

        /**
         * SectionOccupancyCollector's address.
         */
        InetAddress controllerAddress;

        public Requester(Object syncObject) {
            super(syncObject);
            try {
                controllerAddress = InetAddress.getByName("192.168.1.160");
            } catch (UnknownHostException ex) {
                Logger.getLogger(OccupancyController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        @Override
        public void run() {
            while (this.isRunning) {
                try {
                    byte[] message = new byte[]{(byte) Commands.COMMAND_GET_OCCUPANCY};
                    boolean isSended = sendUDPPacket(controllerAddress, message);
                    if (!isSended) {
                        throw new ProgramFlowException("Packet is not sended!");
                    }
                    Thread.sleep(10);
                } catch (Exception ex) {
                    Logger.getLogger(OccupancyController.class.getName()).log(Level.SEVERE, null, ex);
                }

                synchronized (this.heartBeat) {
                    try {
                        this.heartBeat.wait();
                    } catch (InterruptedException ex) {
                        Logger.getLogger(OccupancyController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }

        @Override
        protected void finalize() throws Throwable {
            super.finalize();
        }

    }

}
