/*----------------------------------------------------------------------------
 * File:  Application_OccupiedSection_class.c
 *
 * Class:       OccupiedSection  (OccupiedSection)
 * Component:   Application
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#include "ControlSectionsV5_sys_types.h"
#include "Application_LOG_bridge.h"
#include "Application_Utilities_bridge.h"
#include "Application_classes.h"


/*
 * RELATE Section TO OccupiedSection ACROSS R1
 */
void
Application_OccupiedSection_R1_Link( Application_Section * supertype, Application_OccupiedSection * subtype )
{
  /* Use TagEmptyHandleDetectionOn() to detect empty handle references.  */
  /* Optimized linkage for OccupiedSection->Section[R1] */
  subtype->Section_R1 = supertype;
  /* Optimized linkage for Section->OccupiedSection[R1] */
  supertype->R1_subtype = subtype;
  supertype->R1_object_id = Application_OccupiedSection_CLASS_NUMBER;
}


/*
 * UNRELATE Section FROM OccupiedSection ACROSS R1
 */
void
Application_OccupiedSection_R1_Unlink( Application_Section * supertype, Application_OccupiedSection * subtype )
{
  /* Use TagEmptyHandleDetectionOn() to detect empty handle references.  */
  subtype->Section_R1 = 0;
  /* Note:  Section->OccupiedSection[R1] not navigated */
}


/*
 * Statically allocate space for the instance population for this class.
 * Allocate space for the class instance and its attribute values.
 * Depending upon the collection scheme, allocate containoids (collection
 * nodes) for gathering instances into free and active extents.
 */
static Escher_SetElement_s Application_OccupiedSection_container[ Application_OccupiedSection_MAX_EXTENT_SIZE ];
static Application_OccupiedSection Application_OccupiedSection_instances[ Application_OccupiedSection_MAX_EXTENT_SIZE ];
Escher_Extent_t pG_Application_OccupiedSection_extent = {
  {0}, {0}, &Application_OccupiedSection_container[ 0 ],
  (Escher_iHandle_t) &Application_OccupiedSection_instances,
  sizeof( Application_OccupiedSection ), Application_OccupiedSection_STATE_1, Application_OccupiedSection_MAX_EXTENT_SIZE
  };
/*----------------------------------------------------------------------------
 * State and transition action implementations for the following class:
 *
 * Class:      OccupiedSection  (OccupiedSection)
 * Component:  Application
 *--------------------------------------------------------------------------*/

/*
 * State 1:  [Init]
 */
static void Application_OccupiedSection_act1( Application_OccupiedSection *, const Escher_xtUMLEvent_t * const );
static void
Application_OccupiedSection_act1( Application_OccupiedSection * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * section=0;
  /* SELECT one section RELATED BY self->Section[R1] */
  section = ( 0 != self ) ? self->Section_R1 : 0;
  /* section.sendSectionLock() */
  Application_Section_op_sendSectionLock( section );
}

/*
 * State 2:  [BecomesFree]
 */
static void Application_OccupiedSection_act2( Application_OccupiedSection *, const Escher_xtUMLEvent_t * const );
static void
Application_OccupiedSection_act2( Application_OccupiedSection * self, const Escher_xtUMLEvent_t * const event )
{
  Application_FreeSection * free;Application_Section * section=0;
  /* SELECT one section RELATED BY self->Section[R1] */
  section = ( 0 != self ) ? self->Section_R1 : 0;
  /* section.sendPassingAllowed() */
  Application_Section_op_sendPassingAllowed( section );
  /* UNRELATE self FROM section ACROSS R1 */
  Application_OccupiedSection_R1_Unlink( section, self );
  /* CREATE OBJECT INSTANCE free OF FreeSection */
  free = (Application_FreeSection *) Escher_CreateInstance( Application_DOMAIN_ID, Application_FreeSection_CLASS_NUMBER );
  /* RELATE free TO section ACROSS R1 */
  Application_FreeSection_R1_Link( section, free );
  /* GENERATE Section5:initialized() TO free */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( free, &Application_Sectionevent5c );
    Escher_SendEvent( e );
  }
}

/*
 * State 4:  [BecomesLocked]
 */
static void Application_OccupiedSection_act4( Application_OccupiedSection *, const Escher_xtUMLEvent_t * const );
static void
Application_OccupiedSection_act4( Application_OccupiedSection * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * section=0;
  /* SELECT one section RELATED BY self->Section[R1] */
  section = ( 0 != self ) ? self->Section_R1 : 0;
  /* SEND Port1::disableSection(sectionId:section.id) */
  Application_Port1_disableSection( section->id );
}

/*
 * State 3:  [BecomesUnlocked]
 */
static void Application_OccupiedSection_act3( Application_OccupiedSection *, const Escher_xtUMLEvent_t * const );
static void
Application_OccupiedSection_act3( Application_OccupiedSection * self, const Escher_xtUMLEvent_t * const event )
{
}

/*
 */
static void Application_OccupiedSection_xact1( Application_OccupiedSection *, const Escher_xtUMLEvent_t * const );
static void
Application_OccupiedSection_xact1( Application_OccupiedSection * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * section=0;
  /* SELECT one section RELATED BY self->Section[R1] */
  section = ( 0 != self ) ? self->Section_R1 : 0;
  /* section.sendPassingDenied() */
  Application_Section_op_sendPassingDenied( section );
}

/*
 */
static void Application_OccupiedSection_xact2( Application_OccupiedSection *, const Escher_xtUMLEvent_t * const );
static void
Application_OccupiedSection_xact2( Application_OccupiedSection * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * section=0;
  /* SELECT one section RELATED BY self->Section[R1] */
  section = ( 0 != self ) ? self->Section_R1 : 0;
  /* section.sendPassingDenied() */
  Application_Section_op_sendPassingDenied( section );
}

/*
 */
static void Application_OccupiedSection_xact3( Application_OccupiedSection *, const Escher_xtUMLEvent_t * const );
static void
Application_OccupiedSection_xact3( Application_OccupiedSection * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * section=0;
  /* SELECT one section RELATED BY self->Section[R1] */
  section = ( 0 != self ) ? self->Section_R1 : 0;
  /* section.sendPassingDenied() */
  Application_Section_op_sendPassingDenied( section );
}

/*
 */
static void Application_OccupiedSection_xact4( Application_OccupiedSection *, const Escher_xtUMLEvent_t * const );
static void
Application_OccupiedSection_xact4( Application_OccupiedSection * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * section=0;
  /* SELECT one section RELATED BY self->Section[R1] */
  section = ( 0 != self ) ? self->Section_R1 : 0;
  /* SEND Port1::enableSection(sectionId:section.id) */
  Application_Port1_enableSection( section->id );
}

const Escher_xtUMLEventConstant_t Application_OccupiedSectionevent_Section_PE1c = {
  Application_DOMAIN_ID, Application_OccupiedSection_CLASS_NUMBER, APPLICATION_OCCUPIEDSECTIONEVENT_SECTION_PE1NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_OccupiedSectionevent_Section_PE5c = {
  Application_DOMAIN_ID, Application_OccupiedSection_CLASS_NUMBER, APPLICATION_OCCUPIEDSECTIONEVENT_SECTION_PE5NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_OccupiedSectionevent_Section_PE4c = {
  Application_DOMAIN_ID, Application_OccupiedSection_CLASS_NUMBER, APPLICATION_OCCUPIEDSECTIONEVENT_SECTION_PE4NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_OccupiedSectionevent_Section_PE3c = {
  Application_DOMAIN_ID, Application_OccupiedSection_CLASS_NUMBER, APPLICATION_OCCUPIEDSECTIONEVENT_SECTION_PE3NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_OccupiedSectionevent_Section_PE6c = {
  Application_DOMAIN_ID, Application_OccupiedSection_CLASS_NUMBER, APPLICATION_OCCUPIEDSECTIONEVENT_SECTION_PE6NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_OccupiedSectionevent_Section_PE7c = {
  Application_DOMAIN_ID, Application_OccupiedSection_CLASS_NUMBER, APPLICATION_OCCUPIEDSECTIONEVENT_SECTION_PE7NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };



/*
 * State-Event Matrix (SEM)
 * Row index is object (MC enumerated) current state.
 * Row zero is the uninitialized state (e.g., for creation event transitions).
 * Column index is (MC enumerated) state machine events.
 */
static const Escher_SEMcell_t Application_OccupiedSection_StateEventMatrix[ 4 + 1 ][ 6 ] = {
  /* row 0:  uninitialized state (for creation events) */
  { EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN },
  /* row 1:  Application_OccupiedSection_STATE_1 (Init) */
  { EVENT_IS_IGNORED, (4<<8) + Application_OccupiedSection_STATE_3, Application_OccupiedSection_STATE_4, (2<<8) + Application_OccupiedSection_STATE_4, Application_OccupiedSection_STATE_1, Application_OccupiedSection_STATE_2 },
  /* row 2:  Application_OccupiedSection_STATE_2 (BecomesFree) */
  { EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED },
  /* row 3:  Application_OccupiedSection_STATE_3 (BecomesUnlocked) */
  { Application_OccupiedSection_STATE_1, EVENT_IS_IGNORED, Application_OccupiedSection_STATE_4, (1<<8) + Application_OccupiedSection_STATE_4, EVENT_IS_IGNORED, Application_OccupiedSection_STATE_2 },
  /* row 4:  Application_OccupiedSection_STATE_4 (BecomesLocked) */
  { Application_OccupiedSection_STATE_1, Application_OccupiedSection_STATE_1, EVENT_IS_IGNORED, (3<<8) + Application_OccupiedSection_STATE_4, EVENT_IS_IGNORED, Application_OccupiedSection_STATE_2 }
};

  /*
   * Array of pointers to the class state action procedures.
   * Index is the (MC enumerated) number of the state action to execute.
   */
  static const StateAction_t Application_OccupiedSection_acts[ 5 ] = {
    (StateAction_t) 0,
    (StateAction_t) Application_OccupiedSection_act1,  /* Init */
    (StateAction_t) Application_OccupiedSection_act2,  /* BecomesFree */
    (StateAction_t) Application_OccupiedSection_act3,  /* BecomesUnlocked */
    (StateAction_t) Application_OccupiedSection_act4  /* BecomesLocked */
  };

  /*
   * Array of pointers to the class transition action procedures.
   * Index is the (MC enumerated) number of the transition action to execute.
   */
  static const StateAction_t Application_OccupiedSection_xacts[ 4 ] = {
    (StateAction_t) Application_OccupiedSection_xact1,
    (StateAction_t) Application_OccupiedSection_xact2,
    (StateAction_t) Application_OccupiedSection_xact3,
    (StateAction_t) Application_OccupiedSection_xact4
  };

/*
 * instance state machine event dispatching
 */
void
Application_OccupiedSection_Dispatch( Escher_xtUMLEvent_t * event )
{
  Escher_iHandle_t instance = GetEventTargetInstance( event );
  Escher_EventNumber_t event_number = GetOoaEventNumber( event );
  Escher_StateNumber_t current_state;
  Escher_SEMcell_t next_state;
  
  if ( 0 != instance ) {
    current_state = instance->current_state;
    if ( current_state > 4 ) {
      /* instance validation failure (object deleted while event in flight) */
      UserEventNoInstanceCallout( event_number );
    } else {
      next_state = Application_OccupiedSection_StateEventMatrix[ current_state ][ event_number ];
      if ( next_state <= 4 ) {
        /* Execute the state action and update the current state.  */
        ( *Application_OccupiedSection_acts[ next_state ] )( instance, event );

        /* Self deletion state transition? */
        if ( next_state == Application_OccupiedSection_STATE_2 ) {          Escher_DeleteInstance( instance, Application_DOMAIN_ID, Application_OccupiedSection_CLASS_NUMBER );
        } else {
          instance->current_state = next_state;
        }
      } else if ( next_state == EVENT_IS_IGNORED ) {
          /* event ignored */
      } else {
        ( *Application_OccupiedSection_xacts[ (next_state>>8)-1 ] )( instance, event );
        next_state = next_state & 0x00ff;
        instance->current_state = next_state;
        ( *Application_OccupiedSection_acts[ next_state ] )( instance, event );
      }
    }
  }
}


