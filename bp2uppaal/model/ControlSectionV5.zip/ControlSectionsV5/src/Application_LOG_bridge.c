/*----------------------------------------------------------------------------
 * File:  Application_LOG_bridge.c
 *
 * Description:
 * Methods for bridging to an external entity.
 *
 * External Entity:  Logging (LOG)
 * 
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#include "ControlSectionsV5_sys_types.h"
#include "Application_LOG_bridge.h"
#include "Application_Utilities_bridge.h"
#include "Application_classes.h"
#include "Application_LOG_bridge.h"
#include "ControlSectionsV5_sys_types.h"

/*
 * Bridge:  LogSuccess
 */
void
Application_LOG_LogSuccess( c_t p_message[ESCHER_SYS_MAX_STRING_LEN] )
{
  /* Replace/Insert your implementation code here... */
}


/*
 * Bridge:  LogFailure
 */
void
Application_LOG_LogFailure( c_t p_message[ESCHER_SYS_MAX_STRING_LEN] )
{
  /* Replace/Insert your implementation code here... */
}


/*
 * Bridge:  LogInfo
 */
void
Application_LOG_LogInfo( c_t p_message[ESCHER_SYS_MAX_STRING_LEN] )
{
  /* Replace/Insert your implementation code here... */
}


/*
 * Bridge:  LogDate
 */
void
Application_LOG_LogDate( Escher_Date_t p_d, c_t p_message[ESCHER_SYS_MAX_STRING_LEN] )
{
  /* Replace/Insert your implementation code here... */
}


/*
 * Bridge:  LogTime
 */
void
Application_LOG_LogTime( c_t p_message[ESCHER_SYS_MAX_STRING_LEN], Escher_TimeStamp_t p_t )
{
  /* Replace/Insert your implementation code here... */
}


/*
 * Bridge:  LogReal
 */
void
Application_LOG_LogReal( c_t p_message[ESCHER_SYS_MAX_STRING_LEN], const r_t p_r )
{
  /* Replace/Insert your implementation code here... */
}


/*
 * Bridge:  LogInteger
 */
void
Application_LOG_LogInteger( const i_t p_message )
{
  /* Replace/Insert your implementation code here... */

  /* WARNING!  Skipping unsuccessful or unparsed action.  */
}


