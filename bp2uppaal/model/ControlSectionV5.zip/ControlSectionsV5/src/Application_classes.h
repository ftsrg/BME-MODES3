/*----------------------------------------------------------------------------
 * File:  Application_classes.h
 *
 * This file defines the object type identification numbers for all classes
 * in the component:  Application
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#ifndef APPLICATION_CLASSES_H
#define APPLICATION_CLASSES_H

#ifdef	__cplusplus
extern	"C"	{
#endif

/*
 * Initialization services for component:  Application
 */
extern Escher_Extent_t * const Application_class_info[];
extern const EventTaker_t Application_EventDispatcher[];
void Application_execute_initialization( void );

#define Application_STATE_MODELS 6
/* Define constants to map to class numbers.  */
#define Application_Section_CLASS_NUMBER 0
#define Application_FreeSection_CLASS_NUMBER 1
#define Application_OccupiedSection_CLASS_NUMBER 2
#define Application_Turnout_CLASS_NUMBER 3
#define Application_StraightTurnout_CLASS_NUMBER 4
#define Application_DivergentTurnout_CLASS_NUMBER 5
#define Application_MAX_CLASS_NUMBERS 6

/* Provide a map of classes to task numbers.  */
#define Application_TASK_NUMBERS  0, 0, 0, 0, 0, 0

#define Application_class_dispatchers\
  Application_Section_Dispatch,\
  Application_FreeSection_Dispatch,\
  Application_OccupiedSection_Dispatch,\
  Application_Turnout_Dispatch,\
  Application_StraightTurnout_Dispatch,\
  Application_DivergentTurnout_Dispatch

/* Provide definitions of the shapes of the class structures.  */

typedef struct Application_Section Application_Section;
typedef struct Application_FreeSection Application_FreeSection;
typedef struct Application_OccupiedSection Application_OccupiedSection;
typedef struct Application_Turnout Application_Turnout;
typedef struct Application_StraightTurnout Application_StraightTurnout;
typedef struct Application_DivergentTurnout Application_DivergentTurnout;

/* union of class declarations so we may derive largest class size */
#define Application_CLASS_U \
  char Application_dummy;\

/*
 * UML Domain Functions (Synchronous Services)
 */
void Application_initializeModel( void );


#include "Application_Utilities_bridge.h"
#include "Application_LOG_bridge.h"
#include "Application.h"
#include "Application_Section_class.h"
#include "Application_FreeSection_class.h"
#include "Application_OccupiedSection_class.h"
#include "Application_Turnout_class.h"
#include "Application_StraightTurnout_class.h"
#include "Application_DivergentTurnout_class.h"
/*
 * roll-up of all events (with their parameters) for component Application
 */
typedef union {
  Application_Section_Events_u Application_Section_Events_u_namespace;
  Application_FreeSection_Events_u Application_FreeSection_Events_u_namespace;
  Application_OccupiedSection_Events_u Application_OccupiedSection_Events_u_namespace;
  Application_Turnout_Events_u Application_Turnout_Events_u_namespace;
  Application_StraightTurnout_Events_u Application_StraightTurnout_Events_u_namespace;
  Application_DivergentTurnout_Events_u Application_DivergentTurnout_Events_u_namespace;
} Application_DomainEvents_u;

#ifdef	__cplusplus
}
#endif
#endif  /* APPLICATION_CLASSES_H */

