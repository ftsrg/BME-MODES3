/*----------------------------------------------------------------------------
 * File:  Application_FreeSection_class.c
 *
 * Class:       FreeSection  (FreeSection)
 * Component:   Application
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#include "ControlSectionsV5_sys_types.h"
#include "Application_LOG_bridge.h"
#include "Application_Utilities_bridge.h"
#include "Application_classes.h"


/*
 * RELATE Section TO FreeSection ACROSS R1
 */
void
Application_FreeSection_R1_Link( Application_Section * supertype, Application_FreeSection * subtype )
{
  /* Use TagEmptyHandleDetectionOn() to detect empty handle references.  */
  /* Optimized linkage for FreeSection->Section[R1] */
  subtype->Section_R1 = supertype;
  /* Optimized linkage for Section->FreeSection[R1] */
  supertype->R1_subtype = subtype;
  supertype->R1_object_id = Application_FreeSection_CLASS_NUMBER;
}


/*
 * UNRELATE Section FROM FreeSection ACROSS R1
 */
void
Application_FreeSection_R1_Unlink( Application_Section * supertype, Application_FreeSection * subtype )
{
  /* Use TagEmptyHandleDetectionOn() to detect empty handle references.  */
  subtype->Section_R1 = 0;
  /* Note:  Section->FreeSection[R1] not navigated */
}


/*
 * Statically allocate space for the instance population for this class.
 * Allocate space for the class instance and its attribute values.
 * Depending upon the collection scheme, allocate containoids (collection
 * nodes) for gathering instances into free and active extents.
 */
static Escher_SetElement_s Application_FreeSection_container[ Application_FreeSection_MAX_EXTENT_SIZE ];
static Application_FreeSection Application_FreeSection_instances[ Application_FreeSection_MAX_EXTENT_SIZE ];
Escher_Extent_t pG_Application_FreeSection_extent = {
  {0}, {0}, &Application_FreeSection_container[ 0 ],
  (Escher_iHandle_t) &Application_FreeSection_instances,
  sizeof( Application_FreeSection ), Application_FreeSection_STATE_1, Application_FreeSection_MAX_EXTENT_SIZE
  };
/*----------------------------------------------------------------------------
 * State and transition action implementations for the following class:
 *
 * Class:      FreeSection  (FreeSection)
 * Component:  Application
 *--------------------------------------------------------------------------*/

/*
 * State 1:  [Init]
 */
static void Application_FreeSection_act1( Application_FreeSection *, const Escher_xtUMLEvent_t * const );
static void
Application_FreeSection_act1( Application_FreeSection * self, const Escher_xtUMLEvent_t * const event )
{
}

/*
 * State 2:  [BecomesOccupied]
 */
static void Application_FreeSection_act2( Application_FreeSection *, const Escher_xtUMLEvent_t * const );
static void
Application_FreeSection_act2( Application_FreeSection * self, const Escher_xtUMLEvent_t * const event )
{
  Application_OccupiedSection * occupied;Application_Section * section=0;
  /* SELECT one section RELATED BY self->Section[R1] */
  section = ( 0 != self ) ? self->Section_R1 : 0;
  /* section.sendPassingDenied() */
  Application_Section_op_sendPassingDenied( section );
  /* UNRELATE self FROM section ACROSS R1 */
  Application_FreeSection_R1_Unlink( section, self );
  /* CREATE OBJECT INSTANCE occupied OF OccupiedSection */
  occupied = (Application_OccupiedSection *) Escher_CreateInstance( Application_DOMAIN_ID, Application_OccupiedSection_CLASS_NUMBER );
  /* RELATE occupied TO section ACROSS R1 */
  Application_OccupiedSection_R1_Link( section, occupied );
  /* GENERATE Section5:initialized() TO occupied */
  { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( occupied, &Application_Sectionevent5c );
    Escher_SendEvent( e );
  }
}

/*
 */
static void Application_FreeSection_xact1( Application_FreeSection *, const Escher_xtUMLEvent_t * const );
static void
Application_FreeSection_xact1( Application_FreeSection * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * section=0;
  /* SELECT one section RELATED BY self->Section[R1] */
  section = ( 0 != self ) ? self->Section_R1 : 0;
  /* SEND Port1::enableSection(sectionId:section.id) */
  Application_Port1_enableSection( section->id );
}

/*
 */
static void Application_FreeSection_xact2( Application_FreeSection *, const Escher_xtUMLEvent_t * const );
static void
Application_FreeSection_xact2( Application_FreeSection * self, const Escher_xtUMLEvent_t * const event )
{
  Application_Section * section=0;
  /* SELECT one section RELATED BY self->Section[R1] */
  section = ( 0 != self ) ? self->Section_R1 : 0;
  /* section.sendPassingAllowed() */
  Application_Section_op_sendPassingAllowed( section );
}

const Escher_xtUMLEventConstant_t Application_FreeSectionevent_Section_PE2c = {
  Application_DOMAIN_ID, Application_FreeSection_CLASS_NUMBER, APPLICATION_FREESECTIONEVENT_SECTION_PE2NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_FreeSectionevent_Section_PE5c = {
  Application_DOMAIN_ID, Application_FreeSection_CLASS_NUMBER, APPLICATION_FREESECTIONEVENT_SECTION_PE5NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };

const Escher_xtUMLEventConstant_t Application_FreeSectionevent_Section_PE4c = {
  Application_DOMAIN_ID, Application_FreeSection_CLASS_NUMBER, APPLICATION_FREESECTIONEVENT_SECTION_PE4NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_TRUE_EVENT };



/*
 * State-Event Matrix (SEM)
 * Row index is object (MC enumerated) current state.
 * Row zero is the uninitialized state (e.g., for creation event transitions).
 * Column index is (MC enumerated) state machine events.
 */
static const Escher_SEMcell_t Application_FreeSection_StateEventMatrix[ 2 + 1 ][ 3 ] = {
  /* row 0:  uninitialized state (for creation events) */
  { EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN, EVENT_CANT_HAPPEN },
  /* row 1:  Application_FreeSection_STATE_1 (Init) */
  { (2<<8) + Application_FreeSection_STATE_1, (1<<8) + Application_FreeSection_STATE_1, Application_FreeSection_STATE_2 },
  /* row 2:  Application_FreeSection_STATE_2 (BecomesOccupied) */
  { EVENT_IS_IGNORED, EVENT_IS_IGNORED, EVENT_IS_IGNORED }
};

  /*
   * Array of pointers to the class state action procedures.
   * Index is the (MC enumerated) number of the state action to execute.
   */
  static const StateAction_t Application_FreeSection_acts[ 3 ] = {
    (StateAction_t) 0,
    (StateAction_t) Application_FreeSection_act1,  /* Init */
    (StateAction_t) Application_FreeSection_act2  /* BecomesOccupied */
  };

  /*
   * Array of pointers to the class transition action procedures.
   * Index is the (MC enumerated) number of the transition action to execute.
   */
  static const StateAction_t Application_FreeSection_xacts[ 2 ] = {
    (StateAction_t) Application_FreeSection_xact1,
    (StateAction_t) Application_FreeSection_xact2
  };

/*
 * instance state machine event dispatching
 */
void
Application_FreeSection_Dispatch( Escher_xtUMLEvent_t * event )
{
  Escher_iHandle_t instance = GetEventTargetInstance( event );
  Escher_EventNumber_t event_number = GetOoaEventNumber( event );
  Escher_StateNumber_t current_state;
  Escher_SEMcell_t next_state;
  
  if ( 0 != instance ) {
    current_state = instance->current_state;
    if ( current_state > 2 ) {
      /* instance validation failure (object deleted while event in flight) */
      UserEventNoInstanceCallout( event_number );
    } else {
      next_state = Application_FreeSection_StateEventMatrix[ current_state ][ event_number ];
      if ( next_state <= 2 ) {
        /* Execute the state action and update the current state.  */
        ( *Application_FreeSection_acts[ next_state ] )( instance, event );

        /* Self deletion state transition? */
        if ( next_state == Application_FreeSection_STATE_2 ) {          Escher_DeleteInstance( instance, Application_DOMAIN_ID, Application_FreeSection_CLASS_NUMBER );
        } else {
          instance->current_state = next_state;
        }
      } else if ( next_state == EVENT_IS_IGNORED ) {
          /* event ignored */
      } else {
        ( *Application_FreeSection_xacts[ (next_state>>8)-1 ] )( instance, event );
        next_state = next_state & 0x00ff;
        instance->current_state = next_state;
        ( *Application_FreeSection_acts[ next_state ] )( instance, event );
      }
    }
  }
}


