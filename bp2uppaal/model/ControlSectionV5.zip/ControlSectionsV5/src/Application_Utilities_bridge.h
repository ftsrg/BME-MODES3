/*----------------------------------------------------------------------------
 * File:  Application_Utilities_bridge.h
 *
 * Description:
 * Methods for bridging to an external entity.
 *
 * External Entity:  Utilities (Utilities)
 * 
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#ifndef APPLICATION_UTILITIES_BRIDGE_H
#define APPLICATION_UTILITIES_BRIDGE_H
#ifdef	__cplusplus
extern	"C"	{
#endif

#include "ControlSectionsV5_sys_types.h"

i_t Application_Utilities_GetBit( const i_t, const i_t );
c_t * Application_Utilities_IntToString( const i_t );

#ifdef	__cplusplus
}
#endif
#endif   /* APPLICATION_UTILITIES_BRIDGE_H */
