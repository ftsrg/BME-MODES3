/*----------------------------------------------------------------------------
 * File:  Application_Turnout_class.c
 *
 * Class:       Turnout  (Turnout)
 * Component:   Application
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#include "ControlSectionsV5_sys_types.h"
#include "Application_LOG_bridge.h"
#include "Application_Utilities_bridge.h"
#include "Application_classes.h"


/* Accessors to Turnout[R2] subtypes */


/*
 * RELATE Section TO Turnout ACROSS R3
 */
void
Application_Turnout_R3_Link_connects_from_divergent( Application_Section * part, Application_Turnout * form )
{
  /* Use TagEmptyHandleDetectionOn() to detect empty handle references.  */
  form->Section_R3_divergent = part;
  part->Turnout_R3_connects_from_divergent = form;
}

/*
 * RELATE Section TO Turnout ACROSS R4
 */
void
Application_Turnout_R4_Link_connects_from_straight( Application_Section * part, Application_Turnout * form )
{
  /* Use TagEmptyHandleDetectionOn() to detect empty handle references.  */
  form->Section_R4_straight = part;
  part->Turnout_R4_connects_from_straight = form;
}

/*
 * RELATE Section TO Turnout ACROSS R5
 */
void
Application_Turnout_R5_Link_connects_from_top( Application_Section * part, Application_Turnout * form )
{
  /* Use TagEmptyHandleDetectionOn() to detect empty handle references.  */
  form->Section_R5_top = part;
  part->Turnout_R5_connects_from_top = form;
}

/*
 * Statically allocate space for the instance population for this class.
 * Allocate space for the class instance and its attribute values.
 * Depending upon the collection scheme, allocate containoids (collection
 * nodes) for gathering instances into free and active extents.
 */
static Escher_SetElement_s Application_Turnout_container[ Application_Turnout_MAX_EXTENT_SIZE ];
static Application_Turnout Application_Turnout_instances[ Application_Turnout_MAX_EXTENT_SIZE ];
Escher_Extent_t pG_Application_Turnout_extent = {
  {0}, {0}, &Application_Turnout_container[ 0 ],
  (Escher_iHandle_t) &Application_Turnout_instances,
  sizeof( Application_Turnout ), 0, Application_Turnout_MAX_EXTENT_SIZE
  };
/*----------------------------------------------------------------------------
 * State and transition action implementations for the following class:
 *
 * Class:      Turnout  (Turnout)
 * Component:  Application
 *--------------------------------------------------------------------------*/
/*
 * This class is modeled as having a state chart, but it has no states.
 * This makes good sense in a supertype class receiving polymorphic events.
 * If this is not the intention, add states to the model or unmark the
 * instance or class state chart setting.
 */
static void empty_state_chart_action( void );
static void empty_state_chart_action( void ) {}

const Escher_xtUMLEventConstant_t Application_Turnoutevent1c = {
  Application_DOMAIN_ID, Application_Turnout_CLASS_NUMBER, APPLICATION_TURNOUTEVENT1NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Turnoutevent2c = {
  Application_DOMAIN_ID, Application_Turnout_CLASS_NUMBER, APPLICATION_TURNOUTEVENT2NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Turnoutevent3c = {
  Application_DOMAIN_ID, Application_Turnout_CLASS_NUMBER, APPLICATION_TURNOUTEVENT3NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Turnoutevent4c = {
  Application_DOMAIN_ID, Application_Turnout_CLASS_NUMBER, APPLICATION_TURNOUTEVENT4NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Turnoutevent5c = {
  Application_DOMAIN_ID, Application_Turnout_CLASS_NUMBER, APPLICATION_TURNOUTEVENT5NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Turnoutevent6c = {
  Application_DOMAIN_ID, Application_Turnout_CLASS_NUMBER, APPLICATION_TURNOUTEVENT6NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Turnoutevent7c = {
  Application_DOMAIN_ID, Application_Turnout_CLASS_NUMBER, APPLICATION_TURNOUTEVENT7NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Turnoutevent8c = {
  Application_DOMAIN_ID, Application_Turnout_CLASS_NUMBER, APPLICATION_TURNOUTEVENT8NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Turnoutevent9c = {
  Application_DOMAIN_ID, Application_Turnout_CLASS_NUMBER, APPLICATION_TURNOUTEVENT9NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Turnoutevent10c = {
  Application_DOMAIN_ID, Application_Turnout_CLASS_NUMBER, APPLICATION_TURNOUTEVENT10NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Turnoutevent11c = {
  Application_DOMAIN_ID, Application_Turnout_CLASS_NUMBER, APPLICATION_TURNOUTEVENT11NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Turnoutevent12c = {
  Application_DOMAIN_ID, Application_Turnout_CLASS_NUMBER, APPLICATION_TURNOUTEVENT12NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };



/*
 * No transitions in state model, but polymorphic events are present.
 * This dispatch level will move a polymorphic event down the relationship
 * hierarchy as dictated by the application analysis.
 */
void
Application_Turnout_Dispatch( Escher_xtUMLEvent_t * event )
{
  Escher_iHandle_t instance = GetEventTargetInstance( event );
  if ( 0 != GetIsPolymorphicEvent( event ) ) {
    Application_Turnout_R2PolymorphicEvent( (Application_Turnout *) instance, event );
  }
}
/*
 * Transfer a polymorphic event down the R2 subtype hierarchy
 * to the dispatcher of the subtype that responds to the polymorphic event.
 * Modify the event to use the event constants of the receiving subtype
 * class.
 */
void
Application_Turnout_R2PolymorphicEvent( const Application_Turnout * const p_turnout, Escher_xtUMLEvent_t * event )
{
  Escher_EventNumber_t event_number = GetOoaEventNumber( event );
  if ( 0 != p_turnout->R2_subtype )
  switch ( p_turnout->R2_object_id ) {
    case Application_DivergentTurnout_CLASS_NUMBER:  /* DivergentTurnout (DivergentTurnout) */
      switch ( event_number ) {
        /* transition (or cant happen) events in subtype */
        case APPLICATION_TURNOUTEVENT1NUM:  /* Turnout1*'sectionLockFromDiv' */
          event = Escher_ModifyxtUMLEvent( event, &Application_DivergentTurnoutevent_Turnout_PE1c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_DivergentTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT2NUM:  /* Turnout2*'sectionLockFromStr' */
          event = Escher_ModifyxtUMLEvent( event, &Application_DivergentTurnoutevent_Turnout_PE2c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_DivergentTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT3NUM:  /* Turnout3*'sectionLockFromTop' */
          event = Escher_ModifyxtUMLEvent( event, &Application_DivergentTurnoutevent_Turnout_PE3c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_DivergentTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT4NUM:  /* Turnout4*'passingDeniedFromTop' */
          event = Escher_ModifyxtUMLEvent( event, &Application_DivergentTurnoutevent_Turnout_PE4c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_DivergentTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT5NUM:  /* Turnout5*'passingAllowedFromTop' */
          event = Escher_ModifyxtUMLEvent( event, &Application_DivergentTurnoutevent_Turnout_PE5c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_DivergentTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT6NUM:  /* Turnout6*'switchedStraight' */
          event = Escher_ModifyxtUMLEvent( event, &Application_DivergentTurnoutevent_Turnout_PE6c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_DivergentTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT8NUM:  /* Turnout8*'initialized' */
          event = Escher_ModifyxtUMLEvent( event, &Application_DivergentTurnoutevent_Turnout_PE8c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_DivergentTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT10NUM:  /* Turnout10*'passingDeniedFromDiv' */
          event = Escher_ModifyxtUMLEvent( event, &Application_DivergentTurnoutevent_Turnout_PE10c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_DivergentTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT12NUM:  /* Turnout12*'passingAllowedFromDiv' */
          event = Escher_ModifyxtUMLEvent( event, &Application_DivergentTurnoutevent_Turnout_PE12c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_DivergentTurnout_Dispatch( event );
          break; /* after transition */
      }
      break;
    case Application_StraightTurnout_CLASS_NUMBER:  /* StraightTurnout (StraightTurnout) */
      switch ( event_number ) {
        /* transition (or cant happen) events in subtype */
        case APPLICATION_TURNOUTEVENT1NUM:  /* Turnout1*'sectionLockFromDiv' */
          event = Escher_ModifyxtUMLEvent( event, &Application_StraightTurnoutevent_Turnout_PE1c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_StraightTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT2NUM:  /* Turnout2*'sectionLockFromStr' */
          event = Escher_ModifyxtUMLEvent( event, &Application_StraightTurnoutevent_Turnout_PE2c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_StraightTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT3NUM:  /* Turnout3*'sectionLockFromTop' */
          event = Escher_ModifyxtUMLEvent( event, &Application_StraightTurnoutevent_Turnout_PE3c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_StraightTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT4NUM:  /* Turnout4*'passingDeniedFromTop' */
          event = Escher_ModifyxtUMLEvent( event, &Application_StraightTurnoutevent_Turnout_PE4c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_StraightTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT5NUM:  /* Turnout5*'passingAllowedFromTop' */
          event = Escher_ModifyxtUMLEvent( event, &Application_StraightTurnoutevent_Turnout_PE5c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_StraightTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT7NUM:  /* Turnout7*'switchedDivergent' */
          event = Escher_ModifyxtUMLEvent( event, &Application_StraightTurnoutevent_Turnout_PE7c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_StraightTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT8NUM:  /* Turnout8*'initialized' */
          event = Escher_ModifyxtUMLEvent( event, &Application_StraightTurnoutevent_Turnout_PE8c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_StraightTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT9NUM:  /* Turnout9*'passingDeniedFromStr' */
          event = Escher_ModifyxtUMLEvent( event, &Application_StraightTurnoutevent_Turnout_PE9c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_StraightTurnout_Dispatch( event );
          break; /* after transition */
        case APPLICATION_TURNOUTEVENT11NUM:  /* Turnout11*'passingAllowedFromStr' */
          event = Escher_ModifyxtUMLEvent( event, &Application_StraightTurnoutevent_Turnout_PE11c );
          SetEventTargetInstance( event, p_turnout->R2_subtype );
          Application_StraightTurnout_Dispatch( event );
          break; /* after transition */
      }
      break;
  }
}


