/*----------------------------------------------------------------------------
 * File:  Application_Section_class.h
 *
 * Class:       Section  (Section)
 * Component:   Application
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#ifndef APPLICATION_SECTION_CLASS_H
#define APPLICATION_SECTION_CLASS_H

#ifdef	__cplusplus
extern	"C"	{
#endif

/*
 * Structural representation of application analysis class:
 *   Section  (Section)
 */
struct Application_Section {
  Escher_StateNumber_t current_state;
  /* application analysis class attributes */
  i_t id;  /* - id */

  /* relationship storage */
  void * R1_subtype;
  Escher_ClassNumber_t R1_object_id;
  Application_Turnout * Turnout_R3_connects_from_divergent;
  Application_Turnout * Turnout_R4_connects_from_straight;
  Application_Turnout * Turnout_R5_connects_from_top;
};
void Application_Section_op_sendSectionLock( Application_Section * );
void Application_Section_op_sendPassingDenied( Application_Section * );
void Application_Section_op_sendPassingAllowed( Application_Section * );


/* Accessors to Section[R1] subtypes */
#define Application_FreeSection_R1_From_Section( Section ) \
   ( (((Section)->R1_object_id) == Application_FreeSection_CLASS_NUMBER) ? \
     ((Application_FreeSection *)((Section)->R1_subtype)) : (0) )
#define Application_OccupiedSection_R1_From_Section( Section ) \
   ( (((Section)->R1_object_id) == Application_OccupiedSection_CLASS_NUMBER) ? \
     ((Application_OccupiedSection *)((Section)->R1_subtype)) : (0) )



#define Application_Section_MAX_EXTENT_SIZE 10
extern Escher_Extent_t pG_Application_Section_extent;

/*
 * instance event:  Section1:'sectionFree'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Sectionevent1;
extern const Escher_xtUMLEventConstant_t Application_Sectionevent1c;

/*
 * instance event:  Section2:'sectionOccupied'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Sectionevent2;
extern const Escher_xtUMLEventConstant_t Application_Sectionevent2c;

/*
 * instance event:  Section3:'sectionLocked'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Sectionevent3;
extern const Escher_xtUMLEventConstant_t Application_Sectionevent3c;

/*
 * instance event:  Section4:'sectionLockedWithReply'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Sectionevent4;
extern const Escher_xtUMLEventConstant_t Application_Sectionevent4c;

/*
 * instance event:  Section5:'initialized'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Sectionevent5;
extern const Escher_xtUMLEventConstant_t Application_Sectionevent5c;

/*
 * instance event:  Section6:'sectionAllowed'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Sectionevent6;
extern const Escher_xtUMLEventConstant_t Application_Sectionevent6c;

/*
 * instance event:  Section7:'revokeLock'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Sectionevent7;
extern const Escher_xtUMLEventConstant_t Application_Sectionevent7c;

/*
 * union of events targeted towards 'Section' state machine
 */
typedef union {
  Application_Sectionevent1 section11;  /* polymorphic event - not consumed by Section */
  Application_Sectionevent2 section22;  /* polymorphic event - not consumed by Section */
  Application_Sectionevent3 section33;  /* polymorphic event - not consumed by Section */
  Application_Sectionevent4 section44;  /* polymorphic event - not consumed by Section */
  Application_Sectionevent5 section55;  /* polymorphic event - not consumed by Section */
  Application_Sectionevent6 section66;  /* polymorphic event - not consumed by Section */
  Application_Sectionevent7 section77;  /* polymorphic event - not consumed by Section */
} Application_Section_Events_u;

/* WARNING! No states defined for state model */

/*
 * Enumeration of polymorphic event numbers
 */
#define APPLICATION_SECTIONEVENT1NUM 0  /* Section1:'sectionFree' */
#define APPLICATION_SECTIONEVENT2NUM 1  /* Section2:'sectionOccupied' */
#define APPLICATION_SECTIONEVENT3NUM 2  /* Section3:'sectionLocked' */
#define APPLICATION_SECTIONEVENT4NUM 3  /* Section4:'sectionLockedWithReply' */
#define APPLICATION_SECTIONEVENT5NUM 4  /* Section5:'initialized' */
#define APPLICATION_SECTIONEVENT6NUM 5  /* Section6:'sectionAllowed' */
#define APPLICATION_SECTIONEVENT7NUM 6  /* Section7:'revokeLock' */
extern void Application_Section_Dispatch( Escher_xtUMLEvent_t * );
extern void Application_Section_R1PolymorphicEvent( const Application_Section * const, Escher_xtUMLEvent_t * );

#ifdef	__cplusplus
}
#endif

#endif  /* APPLICATION_SECTION_CLASS_H */


