package interfaces;

import com.mentor.nucleus.bp.core.ComponentInstance_c;

public interface ICommunicationToProvider {

	public void enableSection(ComponentInstance_c senderReceiver, int sectionId);

	public void disableSection(ComponentInstance_c senderReceiver, int sectionId);

	public void initRealized(ComponentInstance_c senderReceiver);

}
