package interfaces;

import com.mentor.nucleus.bp.core.ComponentInstance_c;

public interface ICommunicationFromProvider {
	public void receiveOccupancy(ComponentInstance_c senderReceiver,
			int occupancy);

	public void turnoutDivergent(ComponentInstance_c senderReceiver, int turnoutId);

	public void turnoutStraight(ComponentInstance_c senderReceiver, int turnoutId);

	public void triggerUnlock(ComponentInstance_c senderReceiver);
}
