/*----------------------------------------------------------------------------
 * File:  Application_FreeSection_class.h
 *
 * Class:       FreeSection  (FreeSection)
 * Component:   Application
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#ifndef APPLICATION_FREESECTION_CLASS_H
#define APPLICATION_FREESECTION_CLASS_H

#ifdef	__cplusplus
extern	"C"	{
#endif

/*
 * Structural representation of application analysis class:
 *   FreeSection  (FreeSection)
 */
struct Application_FreeSection {
  Escher_StateNumber_t current_state;
  /* application analysis class attributes */

  /* relationship storage */
  Application_Section * Section_R1;
};

void Application_FreeSection_R1_Link( Application_Section *, Application_FreeSection * );
void Application_FreeSection_R1_Unlink( Application_Section *, Application_FreeSection * );


#define Application_FreeSection_MAX_EXTENT_SIZE 10
extern Escher_Extent_t pG_Application_FreeSection_extent;

/*
 * instance event:  Section2*:'sectionOccupied'
 * Note:  Event is mapped from polymorphic event Section::Section2. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_FreeSectionevent_Section_PE2;
extern const Escher_xtUMLEventConstant_t Application_FreeSectionevent_Section_PE2c;

/*
 * instance event:  Section5*:'initialized'
 * Note:  Event is mapped from polymorphic event Section::Section5. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_FreeSectionevent_Section_PE5;
extern const Escher_xtUMLEventConstant_t Application_FreeSectionevent_Section_PE5c;

/*
 * instance event:  Section4*:'sectionLockedWithReply'
 * Note:  Event is mapped from polymorphic event Section::Section4. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_FreeSectionevent_Section_PE4;
extern const Escher_xtUMLEventConstant_t Application_FreeSectionevent_Section_PE4c;

/*
 * union of events targeted towards 'FreeSection' state machine
 */
typedef union {
  Application_FreeSectionevent_Section_PE2 freesection21;  
  Application_FreeSectionevent_Section_PE5 freesection52;  
  Application_FreeSectionevent_Section_PE4 freesection43;  
} Application_FreeSection_Events_u;

/*
 * enumeration of state model states for class
 */
#define Application_FreeSection_STATE_1 1  /* state [1]:  (Init) */
#define Application_FreeSection_STATE_2 2  /* state [2]:  (BecomesOccupied) */
/*
 * enumeration of state model event numbers
 */
#define APPLICATION_FREESECTIONEVENT_SECTION_PE4NUM 0  /* Section4*:'sectionLockedWithReply' */
#define APPLICATION_FREESECTIONEVENT_SECTION_PE5NUM 1  /* Section5*:'initialized' */
#define APPLICATION_FREESECTIONEVENT_SECTION_PE2NUM 2  /* Section2*:'sectionOccupied' */
extern void Application_FreeSection_Dispatch( Escher_xtUMLEvent_t * );

#ifdef	__cplusplus
}
#endif

#endif  /* APPLICATION_FREESECTION_CLASS_H */


