/*----------------------------------------------------------------------------
 * File:  Application_Section_class.c
 *
 * Class:       Section  (Section)
 * Component:   Application
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#include "ControlSectionsV5_sys_types.h"
#include "Application_LOG_bridge.h"
#include "Application_Utilities_bridge.h"
#include "Application_classes.h"

/*
 * instance operation:  sendSectionLock
 */
void
Application_Section_op_sendSectionLock( Application_Section * self)
{
  Application_Turnout * divConnection=0;
  /* SELECT one divConnection RELATED BY self->Turnout[R3.connects from divergent] */
  divConnection = ( 0 != self ) ? self->Turnout_R3_connects_from_divergent : 0;
  /* IF ( not empty divConnection ) */
  if ( !( 0 == divConnection ) ) {
    /* GENERATE Turnout1:sectionLockFromDiv() TO divConnection */
    { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( divConnection, &Application_Turnoutevent1c );
      Escher_SendEvent( e );
    }
  }
  else {
    Application_Turnout * strConnection=0;
    /* SELECT one strConnection RELATED BY self->Turnout[R4.connects from straight] */
    strConnection = ( 0 != self ) ? self->Turnout_R4_connects_from_straight : 0;
    /* IF ( not empty strConnection ) */
    if ( !( 0 == strConnection ) ) {
      /* GENERATE Turnout2:sectionLockFromStr() TO strConnection */
      { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( strConnection, &Application_Turnoutevent2c );
        Escher_SendEvent( e );
      }
    }
    else {
      Application_Turnout * topConnection=0;
      /* SELECT one topConnection RELATED BY self->Turnout[R5.connects from top] */
      topConnection = ( 0 != self ) ? self->Turnout_R5_connects_from_top : 0;
      /* IF ( not empty topConnection ) */
      if ( !( 0 == topConnection ) ) {
        /* GENERATE Turnout3:sectionLockFromTop() TO topConnection */
        { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( topConnection, &Application_Turnoutevent3c );
          Escher_SendEvent( e );
        }
      }
    }
  }

}

/*
 * instance operation:  sendPassingDenied
 */
void
Application_Section_op_sendPassingDenied( Application_Section * self)
{
  Application_Turnout * divConnection=0;
  /* SELECT one divConnection RELATED BY self->Turnout[R3.connects from divergent] */
  divConnection = ( 0 != self ) ? self->Turnout_R3_connects_from_divergent : 0;
  /* IF ( not empty divConnection ) */
  if ( !( 0 == divConnection ) ) {
    /* GENERATE Turnout10:passingDeniedFromDiv() TO divConnection */
    { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( divConnection, &Application_Turnoutevent10c );
      Escher_SendEvent( e );
    }
  }
  else {
    Application_Turnout * strConnection=0;
    /* SELECT one strConnection RELATED BY self->Turnout[R4.connects from straight] */
    strConnection = ( 0 != self ) ? self->Turnout_R4_connects_from_straight : 0;
    /* IF ( not empty strConnection ) */
    if ( !( 0 == strConnection ) ) {
      /* GENERATE Turnout9:passingDeniedFromStr() TO strConnection */
      { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( strConnection, &Application_Turnoutevent9c );
        Escher_SendEvent( e );
      }
    }
    else {
      Application_Turnout * topConnection=0;
      /* SELECT one topConnection RELATED BY self->Turnout[R5.connects from top] */
      topConnection = ( 0 != self ) ? self->Turnout_R5_connects_from_top : 0;
      /* IF ( not empty topConnection ) */
      if ( !( 0 == topConnection ) ) {
        /* GENERATE Turnout4:passingDeniedFromTop() TO topConnection */
        { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( topConnection, &Application_Turnoutevent4c );
          Escher_SendEvent( e );
        }
      }
    }
  }

}

/*
 * instance operation:  sendPassingAllowed
 */
void
Application_Section_op_sendPassingAllowed( Application_Section * self)
{
  Application_Turnout * divConnection=0;
  /* SELECT one divConnection RELATED BY self->Turnout[R3.connects from divergent] */
  divConnection = ( 0 != self ) ? self->Turnout_R3_connects_from_divergent : 0;
  /* IF ( not empty divConnection ) */
  if ( !( 0 == divConnection ) ) {
    /* GENERATE Turnout12:passingAllowedFromDiv() TO divConnection */
    { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( divConnection, &Application_Turnoutevent12c );
      Escher_SendEvent( e );
    }
  }
  else {
    Application_Turnout * strConnection=0;
    /* SELECT one strConnection RELATED BY self->Turnout[R4.connects from straight] */
    strConnection = ( 0 != self ) ? self->Turnout_R4_connects_from_straight : 0;
    /* IF ( not empty strConnection ) */
    if ( !( 0 == strConnection ) ) {
      /* GENERATE Turnout11:passingAllowedFromStr() TO strConnection */
      { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( strConnection, &Application_Turnoutevent11c );
        Escher_SendEvent( e );
      }
    }
    else {
      Application_Turnout * topConnection=0;
      /* SELECT one topConnection RELATED BY self->Turnout[R5.connects from top] */
      topConnection = ( 0 != self ) ? self->Turnout_R5_connects_from_top : 0;
      /* IF ( not empty topConnection ) */
      if ( !( 0 == topConnection ) ) {
        /* GENERATE Turnout5:passingAllowedFromTop() TO topConnection */
        { Escher_xtUMLEvent_t * e = Escher_NewxtUMLEvent( topConnection, &Application_Turnoutevent5c );
          Escher_SendEvent( e );
        }
      }
    }
  }

}


/* Accessors to Section[R1] subtypes */



/*----------------------------------------------------------------------------
 * Operation action methods implementation for the following class:
 *
 * Class:      Section  (Section)
 * Component:  Application
 *--------------------------------------------------------------------------*/
/*
 * Statically allocate space for the instance population for this class.
 * Allocate space for the class instance and its attribute values.
 * Depending upon the collection scheme, allocate containoids (collection
 * nodes) for gathering instances into free and active extents.
 */
static Escher_SetElement_s Application_Section_container[ Application_Section_MAX_EXTENT_SIZE ];
static Application_Section Application_Section_instances[ Application_Section_MAX_EXTENT_SIZE ];
Escher_Extent_t pG_Application_Section_extent = {
  {0}, {0}, &Application_Section_container[ 0 ],
  (Escher_iHandle_t) &Application_Section_instances,
  sizeof( Application_Section ), 0, Application_Section_MAX_EXTENT_SIZE
  };
/*----------------------------------------------------------------------------
 * State and transition action implementations for the following class:
 *
 * Class:      Section  (Section)
 * Component:  Application
 *--------------------------------------------------------------------------*/
/*
 * This class is modeled as having a state chart, but it has no states.
 * This makes good sense in a supertype class receiving polymorphic events.
 * If this is not the intention, add states to the model or unmark the
 * instance or class state chart setting.
 */
static void empty_state_chart_action( void );
static void empty_state_chart_action( void ) {}

const Escher_xtUMLEventConstant_t Application_Sectionevent1c = {
  Application_DOMAIN_ID, Application_Section_CLASS_NUMBER, APPLICATION_SECTIONEVENT1NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Sectionevent2c = {
  Application_DOMAIN_ID, Application_Section_CLASS_NUMBER, APPLICATION_SECTIONEVENT2NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Sectionevent3c = {
  Application_DOMAIN_ID, Application_Section_CLASS_NUMBER, APPLICATION_SECTIONEVENT3NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Sectionevent4c = {
  Application_DOMAIN_ID, Application_Section_CLASS_NUMBER, APPLICATION_SECTIONEVENT4NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Sectionevent5c = {
  Application_DOMAIN_ID, Application_Section_CLASS_NUMBER, APPLICATION_SECTIONEVENT5NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Sectionevent6c = {
  Application_DOMAIN_ID, Application_Section_CLASS_NUMBER, APPLICATION_SECTIONEVENT6NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };

const Escher_xtUMLEventConstant_t Application_Sectionevent7c = {
  Application_DOMAIN_ID, Application_Section_CLASS_NUMBER, APPLICATION_SECTIONEVENT7NUM,
  ESCHER_IS_INSTANCE_EVENT + ESCHER_IS_POLYMORPHIC_EVENT };



/*
 * No transitions in state model, but polymorphic events are present.
 * This dispatch level will move a polymorphic event down the relationship
 * hierarchy as dictated by the application analysis.
 */
void
Application_Section_Dispatch( Escher_xtUMLEvent_t * event )
{
  Escher_iHandle_t instance = GetEventTargetInstance( event );
  if ( 0 != GetIsPolymorphicEvent( event ) ) {
    Application_Section_R1PolymorphicEvent( (Application_Section *) instance, event );
  }
}
/*
 * Transfer a polymorphic event down the R1 subtype hierarchy
 * to the dispatcher of the subtype that responds to the polymorphic event.
 * Modify the event to use the event constants of the receiving subtype
 * class.
 */
void
Application_Section_R1PolymorphicEvent( const Application_Section * const p_section, Escher_xtUMLEvent_t * event )
{
  Escher_EventNumber_t event_number = GetOoaEventNumber( event );
  if ( 0 != p_section->R1_subtype )
  switch ( p_section->R1_object_id ) {
    case Application_FreeSection_CLASS_NUMBER:  /* FreeSection (FreeSection) */
      switch ( event_number ) {
        /* transition (or cant happen) events in subtype */
        case APPLICATION_SECTIONEVENT2NUM:  /* Section2*'sectionOccupied' */
          event = Escher_ModifyxtUMLEvent( event, &Application_FreeSectionevent_Section_PE2c );
          SetEventTargetInstance( event, p_section->R1_subtype );
          Application_FreeSection_Dispatch( event );
          break; /* after transition */
        case APPLICATION_SECTIONEVENT4NUM:  /* Section4*'sectionLockedWithReply' */
          event = Escher_ModifyxtUMLEvent( event, &Application_FreeSectionevent_Section_PE4c );
          SetEventTargetInstance( event, p_section->R1_subtype );
          Application_FreeSection_Dispatch( event );
          break; /* after transition */
        case APPLICATION_SECTIONEVENT5NUM:  /* Section5*'initialized' */
          event = Escher_ModifyxtUMLEvent( event, &Application_FreeSectionevent_Section_PE5c );
          SetEventTargetInstance( event, p_section->R1_subtype );
          Application_FreeSection_Dispatch( event );
          break; /* after transition */
      }
      break;
    case Application_OccupiedSection_CLASS_NUMBER:  /* OccupiedSection (OccupiedSection) */
      switch ( event_number ) {
        /* transition (or cant happen) events in subtype */
        case APPLICATION_SECTIONEVENT1NUM:  /* Section1*'sectionFree' */
          event = Escher_ModifyxtUMLEvent( event, &Application_OccupiedSectionevent_Section_PE1c );
          SetEventTargetInstance( event, p_section->R1_subtype );
          Application_OccupiedSection_Dispatch( event );
          break; /* after transition */
        case APPLICATION_SECTIONEVENT3NUM:  /* Section3*'sectionLocked' */
          event = Escher_ModifyxtUMLEvent( event, &Application_OccupiedSectionevent_Section_PE3c );
          SetEventTargetInstance( event, p_section->R1_subtype );
          Application_OccupiedSection_Dispatch( event );
          break; /* after transition */
        case APPLICATION_SECTIONEVENT4NUM:  /* Section4*'sectionLockedWithReply' */
          event = Escher_ModifyxtUMLEvent( event, &Application_OccupiedSectionevent_Section_PE4c );
          SetEventTargetInstance( event, p_section->R1_subtype );
          Application_OccupiedSection_Dispatch( event );
          break; /* after transition */
        case APPLICATION_SECTIONEVENT5NUM:  /* Section5*'initialized' */
          event = Escher_ModifyxtUMLEvent( event, &Application_OccupiedSectionevent_Section_PE5c );
          SetEventTargetInstance( event, p_section->R1_subtype );
          Application_OccupiedSection_Dispatch( event );
          break; /* after transition */
        case APPLICATION_SECTIONEVENT6NUM:  /* Section6*'sectionAllowed' */
          event = Escher_ModifyxtUMLEvent( event, &Application_OccupiedSectionevent_Section_PE6c );
          SetEventTargetInstance( event, p_section->R1_subtype );
          Application_OccupiedSection_Dispatch( event );
          break; /* after transition */
        case APPLICATION_SECTIONEVENT7NUM:  /* Section7*'revokeLock' */
          event = Escher_ModifyxtUMLEvent( event, &Application_OccupiedSectionevent_Section_PE7c );
          SetEventTargetInstance( event, p_section->R1_subtype );
          Application_OccupiedSection_Dispatch( event );
          break; /* after transition */
      }
      break;
  }
}


