package components;

import interfaces.ICommunicationFromProvider;
import interfaces.ICommunicationToProvider;

import java.util.ArrayList;
import java.util.List;

import kvcontrol.controllers.OccupancyController;
import kvcontrol.controllers.SectionController;
import kvcontrol.controllers.TurnoutController;
import kvcontrol.exceptions.NotFoundException;
import kvcontrol.interfaces.IOccupancyController;
import kvcontrol.interfaces.ISectionController;
import kvcontrol.interfaces.ITurnoutController;

import com.mentor.nucleus.bp.core.ComponentInstance_c;
import com.mentor.nucleus.bp.core.CorePlugin;

public class RArduino implements ICommunicationToProvider {

	public static final boolean DEBUG_ENABLED = false;

	private IOccupancyController oc;
	private ISectionController sc;
	private ITurnoutController tc;

	private OccupancyTransmitter ot;
	private TurnoutTransmitter tt;
	private UnlockTriggerer ut;

	private List<SectionStatus> sectionStatuses;

	private Object commSyncObject;
	private static ICommunicationFromProvider comm;

	public RArduino(ICommunicationFromProvider dest) {
		// save the communicating component's reference
		comm = dest;
	}

	@Override
	public void initRealized(ComponentInstance_c senderReceiver) {
		CorePlugin.out.println("Initializing realized component.");

		int port = 8888;
		String myAddress = "192.168.1.165";

		commSyncObject = new Object();

		oc = new OccupancyController(port, myAddress);
		sc = new SectionController(port, myAddress);
		tc = new TurnoutController(port, myAddress);

		oc.startThreads();
		sc.startThreads();
		tc.startThreads();

		ot = new OccupancyTransmitter();
		tt = new TurnoutTransmitter();
		ut = new UnlockTriggerer();

		new Thread(ot).start();
		new Thread(tt).start();
		new Thread(ut).start();

		sectionStatuses = new ArrayList<SectionStatus>();

		sectionStatuses.add(new SectionStatus(8, true));
		sectionStatuses.add(new SectionStatus(11, true));
		sectionStatuses.add(new SectionStatus(23, true));

		CorePlugin.out.println("Initialization completed.");
	}

	@Override
	public void enableSection(ComponentInstance_c senderReceiver, int sectionId) {
		try {
			synchronized (sectionStatuses) {
				for (SectionStatus status : sectionStatuses) {
					if (status.id == sectionId && !status.isEnabled) {
						CorePlugin.out.println(sectionId + " is enabled.");
						sc.setSectionEnabled(sectionId);
						status.isEnabled = true;
					}
				}
			}
		} catch (NotFoundException e) {
			CorePlugin.out.println(e.getMessage());
		}
	}

	@Override
	public void disableSection(ComponentInstance_c senderReceiver, int sectionId) {
		try {
			synchronized (sectionStatuses) {
				for (SectionStatus status : sectionStatuses) {
					if (status.id == sectionId && status.isEnabled) {
						CorePlugin.out.println(sectionId + " is disabled.");
						sc.setSectionDisabled(sectionId);
						status.isEnabled = false;
					}
				}
			}
		} catch (NotFoundException e) {
			CorePlugin.out.println(e.getMessage());
		}
	}

	private class OccupancyTransmitter implements Runnable {

		private boolean isRunning = true;

		@Override
		public void run() {
			while (isRunning) {
				try {
					oc.sendHeartBeat();
//					CorePlugin.out.println("-- oc send heart beat");
					int occupancyVector = oc.getOccupancyVector();
					CorePlugin.out
							.println(Integer.toString(occupancyVector, 2));
//					CorePlugin.out.println("-- occupancy printed");
					synchronized (commSyncObject) {
						if (comm != null) {
//							CorePlugin.out.println("-- before comm.receiveOccupancy");
							comm.receiveOccupancy(null, occupancyVector);
//							CorePlugin.out.println("-- comm receive occupancy");
						}
					}
					if (DEBUG_ENABLED) {
						CorePlugin.out.println("-- occupancy queried.");
					}
					Thread.sleep(1000);
//					CorePlugin.out.println("-- oc thread woke up");
				} catch (InterruptedException e) {
					CorePlugin.out.println(e.getMessage());
				} catch (NullPointerException e) {
					CorePlugin.out.println(e + " -----");
//					for (StackTraceElement element : e.getCause()
//							.getStackTrace()) {
//						CorePlugin.out.println(element.getClassName() + " "
//								+ element.getLineNumber() + " "
//								+ element.getMethodName());
//					}
				}catch (Exception e) {
					CorePlugin.out.println("------------------");
					CorePlugin.out.println(e);
					CorePlugin.out.println(e.getMessage());
//					for (StackTraceElement element : e.getCause()
//							.getStackTrace()) {
//						CorePlugin.out.println(element.getClassName() + " "
//								+ element.getLineNumber() + " "
//								+ element.getMethodName());
//					}
				}
			}
		}

		private void stop() {
			isRunning = false;
		}

		@Override
		protected void finalize() throws Throwable {
			stop();
		}
	}

	private class TurnoutTransmitter implements Runnable {

		private boolean isRunning = true;

		private int turnoutId = 131;

		@Override
		public void run() {
			while (isRunning) {
				try {
					tc.sendHeartBeat();
//					CorePlugin.out.println("tc send heart beat");
					boolean straight = tc.isTurnoutStraight(turnoutId);
//					CorePlugin.out.println(straight + " ****");
					synchronized (commSyncObject) {
						if (comm != null) {
							if (!straight) {
//								CorePlugin.out.println("before comm.turnoutDivergent");
								comm.turnoutDivergent(null, turnoutId);
								CorePlugin.out.println("tc divergent");
							} else {
//								CorePlugin.out.println("before comm.turnoutStraight");
								comm.turnoutStraight(null, turnoutId);
								CorePlugin.out.println("tc straight");
							}
						}
					}
					 if (DEBUG_ENABLED) {
					CorePlugin.out.println("turnout queried.");
					 }
					Thread.sleep(1500);
//					CorePlugin.out.println("tc woke up");
				} catch (NotFoundException e) {
					CorePlugin.out.println(e.getMessage());
				} catch (InterruptedException e) {
					CorePlugin.out.println(e.getMessage());
				} catch (NullPointerException e) {
					CorePlugin.out.println(e + "*******");
//					for (StackTraceElement element : e.getCause()
//							.getStackTrace()) {
//						CorePlugin.out.println(element.getClassName() + " "
//								+ element.getLineNumber() + " "
//								+ element.getMethodName());
//					}
				}catch (Exception e) {
					CorePlugin.out.println("****************");
					CorePlugin.out.println(e);
					CorePlugin.out.println(e.getMessage());
//					for (StackTraceElement element : e.getCause()
//							.getStackTrace()) {
//						CorePlugin.out.println(element.getClassName() + " "
//								+ element.getLineNumber() + " "
//								+ element.getMethodName());
//					}
				}
			}

		}

		private void stop() {
			isRunning = false;
		}

		@Override
		protected void finalize() throws Throwable {
			stop();
		}
	}

	private class UnlockTriggerer implements Runnable {

		private boolean isRunning = true;

		@Override
		public void run() {
			while (isRunning) {
				synchronized (commSyncObject) {
					if (comm != null) {
						comm.triggerUnlock(null);
					}
				}
				try {
					if (DEBUG_ENABLED) {
						CorePlugin.out.println("unlock triggered.");
					}
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					CorePlugin.out.println(e.getMessage());
				}
			}

		}

		private void stop() {
			isRunning = false;
		}

		@Override
		protected void finalize() throws Throwable {
			stop();
		}
	}

	private class SectionStatus {
		private final int id;
		private boolean isEnabled;

		public SectionStatus(int id, boolean isEnabled) {
			this.id = id;
			this.isEnabled = isEnabled;
		}
	}

	public void terminate() {
		CorePlugin.out.println("DISPOSE STARTED");
		// stop the threads
		ot.stop();
		tt.stop();
		ut.stop();
		// stop the kvcontrol library
		try {
			oc.stopSystem();
			sc.stopSystem();
			tc.stopSystem();
		} catch (Throwable t) {
			CorePlugin.out.println(t.getMessage());
		}
		CorePlugin.out.println("Threads terminated!");
	}
}