/*----------------------------------------------------------------------------
 * File:  Application_Turnout_class.h
 *
 * Class:       Turnout  (Turnout)
 * Component:   Application
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#ifndef APPLICATION_TURNOUT_CLASS_H
#define APPLICATION_TURNOUT_CLASS_H

#ifdef	__cplusplus
extern	"C"	{
#endif

/*
 * Structural representation of application analysis class:
 *   Turnout  (Turnout)
 */
struct Application_Turnout {
  Escher_StateNumber_t current_state;
  /* application analysis class attributes */
  i_t id;  /* - id */

  /* relationship storage */
  void * R2_subtype;
  Escher_ClassNumber_t R2_object_id;
  Application_Section * Section_R3_divergent;
  Application_Section * Section_R4_straight;
  Application_Section * Section_R5_top;
};


/* Accessors to Turnout[R2] subtypes */
#define Application_DivergentTurnout_R2_From_Turnout( Turnout ) \
   ( (((Turnout)->R2_object_id) == Application_DivergentTurnout_CLASS_NUMBER) ? \
     ((Application_DivergentTurnout *)((Turnout)->R2_subtype)) : (0) )
#define Application_StraightTurnout_R2_From_Turnout( Turnout ) \
   ( (((Turnout)->R2_object_id) == Application_StraightTurnout_CLASS_NUMBER) ? \
     ((Application_StraightTurnout *)((Turnout)->R2_subtype)) : (0) )

void Application_Turnout_R3_Link_connects_from_divergent( Application_Section *, Application_Turnout * );
/* Note:  Section<-R3->Turnout unrelate accessor not needed */
void Application_Turnout_R4_Link_connects_from_straight( Application_Section *, Application_Turnout * );
/* Note:  Section<-R4->Turnout unrelate accessor not needed */
void Application_Turnout_R5_Link_connects_from_top( Application_Section *, Application_Turnout * );
/* Note:  Section<-R5->Turnout unrelate accessor not needed */


#define Application_Turnout_MAX_EXTENT_SIZE 10
extern Escher_Extent_t pG_Application_Turnout_extent;

/*
 * instance event:  Turnout1:'sectionLockFromDiv'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Turnoutevent1;
extern const Escher_xtUMLEventConstant_t Application_Turnoutevent1c;

/*
 * instance event:  Turnout2:'sectionLockFromStr'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Turnoutevent2;
extern const Escher_xtUMLEventConstant_t Application_Turnoutevent2c;

/*
 * instance event:  Turnout3:'sectionLockFromTop'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Turnoutevent3;
extern const Escher_xtUMLEventConstant_t Application_Turnoutevent3c;

/*
 * instance event:  Turnout4:'passingDeniedFromTop'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Turnoutevent4;
extern const Escher_xtUMLEventConstant_t Application_Turnoutevent4c;

/*
 * instance event:  Turnout5:'passingAllowedFromTop'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Turnoutevent5;
extern const Escher_xtUMLEventConstant_t Application_Turnoutevent5c;

/*
 * instance event:  Turnout6:'switchedStraight'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Turnoutevent6;
extern const Escher_xtUMLEventConstant_t Application_Turnoutevent6c;

/*
 * instance event:  Turnout7:'switchedDivergent'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Turnoutevent7;
extern const Escher_xtUMLEventConstant_t Application_Turnoutevent7c;

/*
 * instance event:  Turnout8:'initialized'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Turnoutevent8;
extern const Escher_xtUMLEventConstant_t Application_Turnoutevent8c;

/*
 * instance event:  Turnout9:'passingDeniedFromStr'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Turnoutevent9;
extern const Escher_xtUMLEventConstant_t Application_Turnoutevent9c;

/*
 * instance event:  Turnout10:'passingDeniedFromDiv'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Turnoutevent10;
extern const Escher_xtUMLEventConstant_t Application_Turnoutevent10c;

/*
 * instance event:  Turnout11:'passingAllowedFromStr'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Turnoutevent11;
extern const Escher_xtUMLEventConstant_t Application_Turnoutevent11c;

/*
 * instance event:  Turnout12:'passingAllowedFromDiv'
 */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_Turnoutevent12;
extern const Escher_xtUMLEventConstant_t Application_Turnoutevent12c;

/*
 * union of events targeted towards 'Turnout' state machine
 */
typedef union {
  Application_Turnoutevent1 turnout11;  /* polymorphic event - not consumed by Turnout */
  Application_Turnoutevent2 turnout22;  /* polymorphic event - not consumed by Turnout */
  Application_Turnoutevent3 turnout33;  /* polymorphic event - not consumed by Turnout */
  Application_Turnoutevent4 turnout44;  /* polymorphic event - not consumed by Turnout */
  Application_Turnoutevent5 turnout55;  /* polymorphic event - not consumed by Turnout */
  Application_Turnoutevent6 turnout66;  /* polymorphic event - not consumed by Turnout */
  Application_Turnoutevent7 turnout77;  /* polymorphic event - not consumed by Turnout */
  Application_Turnoutevent8 turnout88;  /* polymorphic event - not consumed by Turnout */
  Application_Turnoutevent9 turnout99;  /* polymorphic event - not consumed by Turnout */
  Application_Turnoutevent10 turnout1010;  /* polymorphic event - not consumed by Turnout */
  Application_Turnoutevent11 turnout1111;  /* polymorphic event - not consumed by Turnout */
  Application_Turnoutevent12 turnout1212;  /* polymorphic event - not consumed by Turnout */
} Application_Turnout_Events_u;

/* WARNING! No states defined for state model */

/*
 * Enumeration of polymorphic event numbers
 */
#define APPLICATION_TURNOUTEVENT1NUM 0  /* Turnout1:'sectionLockFromDiv' */
#define APPLICATION_TURNOUTEVENT2NUM 1  /* Turnout2:'sectionLockFromStr' */
#define APPLICATION_TURNOUTEVENT3NUM 2  /* Turnout3:'sectionLockFromTop' */
#define APPLICATION_TURNOUTEVENT4NUM 3  /* Turnout4:'passingDeniedFromTop' */
#define APPLICATION_TURNOUTEVENT5NUM 4  /* Turnout5:'passingAllowedFromTop' */
#define APPLICATION_TURNOUTEVENT6NUM 5  /* Turnout6:'switchedStraight' */
#define APPLICATION_TURNOUTEVENT7NUM 6  /* Turnout7:'switchedDivergent' */
#define APPLICATION_TURNOUTEVENT8NUM 7  /* Turnout8:'initialized' */
#define APPLICATION_TURNOUTEVENT9NUM 8  /* Turnout9:'passingDeniedFromStr' */
#define APPLICATION_TURNOUTEVENT10NUM 9  /* Turnout10:'passingDeniedFromDiv' */
#define APPLICATION_TURNOUTEVENT11NUM 10  /* Turnout11:'passingAllowedFromStr' */
#define APPLICATION_TURNOUTEVENT12NUM 11  /* Turnout12:'passingAllowedFromDiv' */
extern void Application_Turnout_Dispatch( Escher_xtUMLEvent_t * );
extern void Application_Turnout_R2PolymorphicEvent( const Application_Turnout * const, Escher_xtUMLEvent_t * );

#ifdef	__cplusplus
}
#endif

#endif  /* APPLICATION_TURNOUT_CLASS_H */


