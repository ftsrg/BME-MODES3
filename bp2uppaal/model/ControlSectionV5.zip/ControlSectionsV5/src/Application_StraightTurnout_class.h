/*----------------------------------------------------------------------------
 * File:  Application_StraightTurnout_class.h
 *
 * Class:       StraightTurnout  (StraightTurnout)
 * Component:   Application
 *
 * your copyright statement can go here (from te_copyright.body)
 *--------------------------------------------------------------------------*/

#ifndef APPLICATION_STRAIGHTTURNOUT_CLASS_H
#define APPLICATION_STRAIGHTTURNOUT_CLASS_H

#ifdef	__cplusplus
extern	"C"	{
#endif

/*
 * Structural representation of application analysis class:
 *   StraightTurnout  (StraightTurnout)
 */
struct Application_StraightTurnout {
  Escher_StateNumber_t current_state;
  /* application analysis class attributes */

  /* relationship storage */
  Application_Turnout * Turnout_R2;
};

void Application_StraightTurnout_R2_Link( Application_Turnout *, Application_StraightTurnout * );
void Application_StraightTurnout_R2_Unlink( Application_Turnout *, Application_StraightTurnout * );


#define Application_StraightTurnout_MAX_EXTENT_SIZE 10
extern Escher_Extent_t pG_Application_StraightTurnout_extent;

/*
 * instance event:  Turnout2*:'sectionLockFromStr'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout2. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_StraightTurnoutevent_Turnout_PE2;
extern const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE2c;

/*
 * instance event:  Turnout5*:'passingAllowedFromTop'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout5. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_StraightTurnoutevent_Turnout_PE5;
extern const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE5c;

/*
 * instance event:  Turnout3*:'sectionLockFromTop'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout3. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_StraightTurnoutevent_Turnout_PE3;
extern const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE3c;

/*
 * instance event:  Turnout4*:'passingDeniedFromTop'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout4. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_StraightTurnoutevent_Turnout_PE4;
extern const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE4c;

/*
 * instance event:  Turnout1*:'sectionLockFromDiv'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout1. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_StraightTurnoutevent_Turnout_PE1;
extern const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE1c;

/*
 * instance event:  Turnout7*:'switchedDivergent'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout7. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_StraightTurnoutevent_Turnout_PE7;
extern const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE7c;

/*
 * instance event:  Turnout8*:'initialized'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout8. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_StraightTurnoutevent_Turnout_PE8;
extern const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE8c;

/*
 * instance event:  Turnout11*:'passingAllowedFromStr'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout11. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_StraightTurnoutevent_Turnout_PE11;
extern const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE11c;

/*
 * instance event:  Turnout9*:'passingDeniedFromStr'
 * Note:  Event is mapped from polymorphic event Turnout::Turnout9. */
typedef struct {
  EVENT_BASE_ATTRIBUTE_LIST         /* base attributes of all event classes */
  /* Note:  no supplemental data for this event */
} Application_StraightTurnoutevent_Turnout_PE9;
extern const Escher_xtUMLEventConstant_t Application_StraightTurnoutevent_Turnout_PE9c;

/*
 * union of events targeted towards 'StraightTurnout' state machine
 */
typedef union {
  Application_StraightTurnoutevent_Turnout_PE2 straightturnout21;  
  Application_StraightTurnoutevent_Turnout_PE5 straightturnout52;  
  Application_StraightTurnoutevent_Turnout_PE3 straightturnout33;  
  Application_StraightTurnoutevent_Turnout_PE4 straightturnout44;  
  Application_StraightTurnoutevent_Turnout_PE1 straightturnout15;  
  Application_StraightTurnoutevent_Turnout_PE7 straightturnout76;  
  Application_StraightTurnoutevent_Turnout_PE8 straightturnout87;  
  Application_StraightTurnoutevent_Turnout_PE11 straightturnout118;  
  Application_StraightTurnoutevent_Turnout_PE9 straightturnout99;  
} Application_StraightTurnout_Events_u;

/*
 * enumeration of state model states for class
 */
#define Application_StraightTurnout_STATE_1 1  /* state [1]:  (Init) */
#define Application_StraightTurnout_STATE_2 2  /* state [2]:  (SwitchedDivergent) */
#define Application_StraightTurnout_STATE_3 3  /* state [3]:  (RequestFromStraight) */
#define Application_StraightTurnout_STATE_4 4  /* state [4]:  (RequestFromTop) */
/*
 * enumeration of state model event numbers
 */
#define APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE9NUM 0  /* Turnout9*:'passingDeniedFromStr' */
#define APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE11NUM 1  /* Turnout11*:'passingAllowedFromStr' */
#define APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE8NUM 2  /* Turnout8*:'initialized' */
#define APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE7NUM 3  /* Turnout7*:'switchedDivergent' */
#define APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE1NUM 4  /* Turnout1*:'sectionLockFromDiv' */
#define APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE4NUM 5  /* Turnout4*:'passingDeniedFromTop' */
#define APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE3NUM 6  /* Turnout3*:'sectionLockFromTop' */
#define APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE5NUM 7  /* Turnout5*:'passingAllowedFromTop' */
#define APPLICATION_STRAIGHTTURNOUTEVENT_TURNOUT_PE2NUM 8  /* Turnout2*:'sectionLockFromStr' */
extern void Application_StraightTurnout_Dispatch( Escher_xtUMLEvent_t * );

#ifdef	__cplusplus
}
#endif

#endif  /* APPLICATION_STRAIGHTTURNOUT_CLASS_H */


